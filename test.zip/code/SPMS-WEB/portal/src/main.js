import i18n from './common/js/i18n' /** I18n国际化配置 **/
import babelpolyfill from 'babel-polyfill'
import Vue from 'vue'
import App from './App'
import ElementUI from 'element-ui'
import './assets/theme/theme-chalk/index.css'/** 主题下载 https://elementui.github.io/theme-chalk-preview/#/zh-CN **/
import store from './vuex/store'
import Vuex from 'vuex'
import router from './common/js/router'
import Utils from './common/js/util'
import Echarts from 'echarts';
import './common/js/prototype.js'//对js运算函数原型进行扩展
import Validate from './common/js/validate'
import 'font-awesome/css/font-awesome.min.css'
import Clickoutside from 'element-ui/lib/utils/clickoutside';//引用elementui点击外部触发事件，关闭下拉框 *******

import Model from './views/model/Model.vue';//引用自定义model弹框框架，可指定不同内容
import SelectTree from './views/model/SelectTree.vue';
import Table from './views/model/Table.vue';

import Permissions from '@/customize/js/permissions';/** 控制系统按钮权限 **/
import * as filters from '@/customize/js/Filter';/** 过滤器实现 **/

Vue.use(ElementUI)
Vue.use(Vuex)
Vue.use(Echarts)
Vue.directive("clickoutside",Clickoutside)
Vue.directive("permissions",Permissions)
Vue.component("el-model",Model)
Vue.component("el-select-tree",SelectTree)
Vue.component("el-grid",Table)

Vue.prototype.$utils = Utils;
Vue.prototype.$echarts = Echarts;
Vue.prototype.$validate = Validate;

// 加载过滤器
Object.keys(filters).forEach(key => { Vue.filter(key, filters[key]); });

document.oncontextmenu = function(){
　　return false;
}

router.beforeEach((to, from, next) => {
  if (to.path == '/login') {
	  sessionStorage.removeItem('user');
	  sessionStorage.removeItem('authorization');//清除token;
  }
  let user = JSON.parse(sessionStorage.getItem('user'));
  if ((!user && to.path != '/login')) {
    next({ path: '/login' })
  } else {
    next()
  }
})

var root = new Vue({
  router,
  i18n,
  store,
  data: { eventHub: new Vue() },/** 创建一个空间VUE实例，用于传播事件 **/
  render: h => h(App)
}).$mount('#app');
Vue.prototype.$app=root;// 将根节点vue对象挂载到Vue原型上，用于新创建的vue对象之间的通讯

