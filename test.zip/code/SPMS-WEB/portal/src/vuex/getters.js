//test
export const getCount = state => {
    return state.count
}

export const theme = state => {
    return state.theme
}