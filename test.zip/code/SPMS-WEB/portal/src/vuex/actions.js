//test
export const increment = ({commit}) => {
    commit('INCREMENT')
}
export const decrement = ({commit}) => {
    commit('DECREMENT')
}
export const set_theme = ({commit}) => {
    commit('SET_THEME')
}
