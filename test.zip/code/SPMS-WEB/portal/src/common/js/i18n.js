import Vue from 'vue'
import VueI18n from 'vue-i18n'
//引入Element的语言包
import ElementUI from 'element-ui'
import enLocale from 'element-ui/lib/locale/lang/en'
import zhLocale from 'element-ui/lib/locale/lang/zh-CN'

Vue.use(VueI18n)

const DEFAULT_LANG = 'en_US'
const LOCALE_KEY = 'localeLanguage'

const locales = {
  'zh_CN': Object.assign({},require('@/customize/i18n/message_zh_CN.json'),zhLocale),
  'en_US': Object.assign({},require('@/customize/i18n/message_en_US.json'),enLocale)
}

const i18n = new VueI18n({
  locale: sessionStorage.getItem(LOCALE_KEY) || DEFAULT_LANG,
  messages: locales
})

i18n.setLang=lang=>{
	  sessionStorage.setItem(LOCALE_KEY,lang);
	  i18n.locale=lang;
}

Vue.use(ElementUI,{
  i18n:(key,value) =>i18n.t(key,value) //重点！！在注册Element时设置i18n的处理方法
});

export default i18n

//在vue模板中，我们直接使用$t("message.hello")来获取语言包变量；
//在vue的js中我们使用this.$i18n.t("message.hello")或者i18n.t("message.hello")来获取语言包变量；
//在vue以外的js中，我们可以使用i18n.t("message.hello")来获取语言包变量；
