import i18n from '@/common/js/i18n' /** I18n国际化配置 **/
var SIGN_REGEXP = /([yMdhsm])(\1*)/g;
var DEFAULT_PATTERN = 'yyyy-MM-dd';
function padding(s, len) {
    var len = len - (s + '').length;
    for (var i = 0; i < len; i++) { s = '0' + s; }
    return s;
};

export default {
    getQueryStringByName: function (name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        var r = window.location.search.substr(1).match(reg);
        var context = "";
        if (r != null)
            context = r[2];
        reg = null;
        r = null;
        return context == null || context == "" || context == "undefined" ? "" : context;
    },
    formatDate: {


        format: function (date, pattern) {
            pattern = pattern || DEFAULT_PATTERN;
            return pattern.replace(SIGN_REGEXP, function ($0) {
                switch ($0.charAt(0)) {
                    case 'y': return padding(date.getFullYear(), $0.length);
                    case 'M': return padding(date.getMonth() + 1, $0.length);
                    case 'd': return padding(date.getDate(), $0.length);
                    case 'w': return date.getDay() + 1;
                    case 'h': return padding(date.getHours(), $0.length);
                    case 'm': return padding(date.getMinutes(), $0.length);
                    case 's': return padding(date.getSeconds(), $0.length);
                }
            });
        },
        parse: function (dateString, pattern) {
            var matchs1 = pattern.match(SIGN_REGEXP);
            var matchs2 = dateString.match(/(\d)+/g);
            if (matchs1.length == matchs2.length) {
                var _date = new Date(1970, 0, 1);
                for (var i = 0; i < matchs1.length; i++) {
                    var _int = parseInt(matchs2[i]);
                    var sign = matchs1[i];
                    switch (sign.charAt(0)) {
                        case 'y': _date.setFullYear(_int); break;
                        case 'M': _date.setMonth(_int - 1); break;
                        case 'd': _date.setDate(_int); break;
                        case 'h': _date.setHours(_int); break;
                        case 'm': _date.setMinutes(_int); break;
                        case 's': _date.setSeconds(_int); break;
                    }
                }
                return _date;
            }
            return null;
        }

    },
    getLabelByValue:function(array,prop,val)
    {
    	if(!array)return val;
    	let temp=[];
    	let valArray = String(val).split(",");
    	valArray.forEach(value => {
    		array.forEach(arr => {
        		if(arr[prop.value]==value)
        		{
        			temp.push(arr[prop.key]);
        		}
        		else if(arr.children)
        		{
    				let childTmp = this.getLabelByValue(arr.children,prop,value);
    				if(childTmp.length)temp.push(childTmp);
        		}
            });
        });
    	return temp.join(",");
    },
    listToTree:function(id,pId,list)
    {
  	  function exists(list, parentId){ for(var i=0; i<list.length; i++){ if (list[i][id] == parentId) return true; } return false; }
	   var nodes = [];
	   list.forEach(row =>{ if (!exists(list, row[pId])){row.level=0;nodes.push(row); } });
	   var toDo = [];
	   nodes.forEach(row => {toDo.push(row)});
	   while(toDo.length){
   	    var node = toDo.shift(); 
   	    list.forEach(row => {
      	     if (row[pId] == node[id]){
      	     row.level=node.level+1;
      	      if (node.children){ node.children.push(row); } else { node.children = [row]; }
      	      toDo.push(row);
      	     }
   	    });
	   }
	   return nodes;
    },
    mergeArray: function(arr1, arr2) {
    	let arr=[];
    	arr1.forEach(num=>{
    		if(arr2.indexOf(num)<0)arr.push(num);
    	})
        return arr;
    },
    bankAccountFormatter:(account)=>{return account.replace(/\s/g, '').replace(/[^\d]/g, '').replace(/(\d{4})(?=\d)/g, '$1 ')},
    shortcuts:()=>{return [{
        text: i18n.t("com.isoftchina.hes.common.lastweek"),
        onClick(picker) { const end = new Date(); const start = new Date(); start.setTime(start.getTime() - 3600 * 1000 * 24 * 7); picker.$emit('pick', [start, end]); }
      }, {
        text: i18n.t("com.isoftchina.hes.common.lastmonth"),
        onClick(picker) { const end = new Date(); const start = new Date(); start.setTime(start.getTime() - 3600 * 1000 * 24 * 30); picker.$emit('pick', [start, end]); }
      }, {
        text: i18n.t("com.isoftchina.hes.common.lastthreemonths"),
        onClick(picker) { const end = new Date(); const start = new Date(); start.setTime(start.getTime() - 3600 * 1000 * 24 * 90); picker.$emit('pick', [start, end]); }
      }]
    }
};
