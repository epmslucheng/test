import i18n from '@/common/js/i18n' /** I18n国际化配置 **/
let checkRule=(rule,value,callback,reg) =>{
	if(!value){return;}
	else if (reg.test(value)) { callback(); } 
    else { callback(new Error(rule.message)); }
}
export default {
	/** 手机号码校验规则 **/
    checkPhoneNumber: (rule, value, callback) => {
    	checkRule(rule,value,callback,/^1[3|4|5|7|8][0-9]\d{8}$/);
    },
    /** 电子邮箱校验规则 **/
    checkEmail: (rule, value, callback) => {
    	checkRule(rule,value,callback,/^\w+((-\w+)|(\.\w+))*\@[a-zA-Z0-9]+((\.|-)[a-zA-Z0-9])*\.[a-zA-Z0-9]+$/);
    },
    /** 固定电话校验规则 **/
    checkTelephone: (rule, value, callback) => {
    	checkRule(rule,value,callback,/^(\(\d{3,4}\)|\d{3,4}-|\s)?\d{7,14}$/);
    },
    /** 身份证号码校验规则 **/
    checkIdCard: (rule, value, callback) => {
    	checkRule(rule,value,callback,/^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/);
    },
    /** 密码校验规则 **/
    checkPassword:(rule, value, callback) =>{
    	if(!value){return;}
    	let pattern = new RegExp("[`~!@#$^&*()=|{}':;',\\[\\].<>《》/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？]");
    	if (!/^.{6,20}$/.test(value)) { callback(new Error(i18n.t('com.isoftchina.hes.common.req3'))); } 
    	else if (!/^.*(\d)+.*$/.test(value)) { callback(new Error(i18n.t('com.isoftchina.hes.common.req4'))); } 
    	else if (!/^.*[a-z]+.*$/.test(value)) { callback(new Error(i18n.t('com.isoftchina.hes.common.req5'))); } 
    	else if (!/^.*[A-Z]+.*$/.test(value)) { callback(new Error(i18n.t('com.isoftchina.hes.common.req6'))); } 
    	else if (!pattern.test(value)) { callback(new Error(i18n.t('com.isoftchina.hes.common.req7'))); } 
    	else{callback();}
    		
    }
};
