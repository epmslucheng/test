import Vue from 'vue'
import VueRouter from 'vue-router'
import routes from '@/router/routes'

const router = new VueRouter({
	mode: 'history',//配置mode，取消‘#’(如果是手机端，则需要将mode注释)
	routes: routes,
	sourceRoutes:routes
})

Vue.use(VueRouter)

export default router