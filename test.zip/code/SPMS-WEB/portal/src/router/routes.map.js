export const RoutesMapping={
		"/administrator/1":"/service/administrator/administrator/UserList.vue",
		"/administrator/2":"/service/administrator/administrator/RoleList.vue",
		"/administrator/3":"/service/administrator/administrator/DepartmentList.vue",
		"/log/1":"/service/administrator/log/OperationLog.vue",
		"/system-settings/1":"/service/administrator/system/SystemParams.vue",
		"/system-settings/2":"/service/administrator/system/DataDictionaries.vue",
        "/resource/deviceManager":"/service/resource/device/DeviceManager.vue",
        "/resource/deviceMaintain":"/service/resource/maintenance/EquipmentMaintenance.vue",
		"/resource/deviceQuery":"/service/resource/device/DeviceSearch.vue",
	    "/data/dataQuery":"/service/data/dataQuery/DataManager.vue"
}