import * as systemService from '@/axios/systemService';
import {RoutesMapping} from '@/router/routes.map';
export default {
    data() {
      return {
    	  menuList:[],
    	  menuBasicList:[]
      }
    },
    methods: {
    	initMenu(){
    		setTimeout(()=>{
        		systemService.menuAxios().then(res=>{
            		let routesList=res.obj;
        			if(routesList)
        			{
        				let _routes=this.assembleRouters(routesList);
        				this.$router.addRoutes([]);//清空路由
        				this.$router.addRoutes(_routes);//动态添加路由
        			}
        		});
        	},20);
    	},
    	assembleRouters(routes){
	      	let routeList=[];
	      	routes.forEach(route=>{
	      		routeList.push({
	      			path: route.url,
			        i18nKey: route.name,
			        name:route.name + "-" + Math.random(),// 规避重复name
			        iconCls: route.iconCls,
			        children:[],
			        isLeaf:route.isLeaf,
			        parentId:route.pid,
			        menuId:route.id
	      		});
	      	});
	      	let routesTree=this.$utils.listToTree("menuId","parentId",routeList);
	      	routeList.forEach(route=>{
	      		let view=(1== route.level && !route.isLeaf) ? '/Content.vue' : (RoutesMapping[route.path] || '/Layout.vue');
	      		route.component=(resolve) => require([`@/views${view}`], resolve);
	      	});
	      	this.$root.menuBasicList=routeList;
			this.$root.eventHub.$emit('menuBasicList', this.$root.menuBasicList);
	      	return routesTree;
	      }
    }
}