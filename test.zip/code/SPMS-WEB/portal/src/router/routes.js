import Login from '@/views/Login.vue'
import Password from '@/views/Password.vue'
import Layout from '@/views/Layout.vue'

let routes = [
	{
	    path: '/error',
	    component: Layout,
	    name: '',
	    hidden: true,
	    children: [
	               { path: '/404', component: (resolve) => require([`@/views/404.vue`], resolve), name: ''},
	               { path: '/noAuthority', component: (resolve) => require([`@/views/NoAuthority.vue`], resolve), name: ''}
	           ]
	},           
    {
        path: '/login',
        component: Login,
        name: '',
        hidden: true
    },
    {
        path: '/resetPassword',
        component: Password,
        name: '',
        hidden: true
    },
    {
        path: '/main',
        component: Layout,
        name: "com.isoftchina.hes.layout.header.menu.home",
        isLeaf:true,
        iconCls: '',//图标样式class
        children: [
            { path: '/home', component: (resolve) => require([`@/views/Main.vue`], resolve), name: ''}
        ]
    },
    {
        path: '*',
        hidden: true,
        redirect: { path: '/home' }
    }
];

export default routes;