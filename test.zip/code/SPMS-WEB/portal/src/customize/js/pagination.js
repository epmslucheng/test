export default {
    data() {
      return {
    	  total:0,
    	  page:{pageNo:1,pageSize:20},
    	  pageSizes:[20, 40, 60, 80],
    	  sels:[],
    	  layout:"total, sizes, prev, pager, next"
      }
    },
    methods: {
    	sizeChange(val) {
			this.page.pageSize=val;
			this.getDataList();
	      },
	      currentChange(val) {
	    	  this.page.pageNo=val;
	    	  this.getDataList();
	      },
	      getCheckedRows(sels){ 
	    	  this.sels=sels; 
	      }
    }
}