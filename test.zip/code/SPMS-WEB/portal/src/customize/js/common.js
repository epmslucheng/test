import Vue from 'vue'
let utils=Vue.prototype.$utils;
/** 单据编号随机码 **/
export const getBillRandomCode = (type,time) => { return type + (time ? new Date().getTime() : utils.formatDate.format(new Date(),"yyyyMMddhhmm")) + Math.floor(Math.random() * 10000); }
