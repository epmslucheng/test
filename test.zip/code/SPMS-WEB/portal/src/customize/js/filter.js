'use strict';

let join = (array,delimite,label) =>{ return array && array.map(item=>label ? item[label] : item).join(delimite); }

export { join }