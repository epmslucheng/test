'use strict';

import Vue from 'vue'

exports.__esModule = true;

/**权限指令**/
exports.default = {
 bind: function (el, binding, vnode) {
  // 获取按钮权限
  //let permissionsList=[];//后续权限控制
  //Vue.prototype.permissions(binding,permissionsList || [],el);
 }
};

// 权限检查方法
Vue.prototype.permissions = (binding,permissionsList,el)=>{
	// 如果是超级管理员
	var user = JSON.parse(sessionStorage.getItem('user'));
	if(user.admin)return;
	let btns=binding.arg.split(",");
	if(btns.length > 1)
	{
		if(!permissionsList.filter(p=>btns.indexOf(p.path)>-1).length){
			let fn=binding.value.fn;
			fn.call(false);//这里就是运行fn
			return;
		}
	}
	else
	{
		if(!permissionsList.find(s=>s.path==binding.arg)){el.parentNode.removeChild(el)};
	}	
}
