import {AxiosInstance} from './intercept';

let base=process.env.BASE_API;

let _axios = AxiosInstance(true);

// 获取系统参数列表
export const getSystemConfigList = params => { return _axios.post(`${base}/SPMS-SERVER/systemConfig/queryPageSystemConfig`, params).then(res => res.data); };

//获取所有系统参数列表
export const getAllSystemConfigList = params => { return _axios.post(`${base}/SPMS-SERVER/systemConfig/queryAllSystemModules`, params).then(res => res.data); };

// 修改系统参数
export const modifySystemConfigInfo = params => { return _axios.post(`${base}/SPMS-SERVER/systemConfig/editSystemConfiguration`, params).then(res => res.data); };

//获取字典列表
export const getDictionariesList = params => { return _axios.post(`${base}/SPMS-SERVER/dictData/queryPageDictType`, params).then(res => res.data); };

//获取所有字典列表
export const getAllDictionariesList = params => { return _axios.post(`${base}/SPMS-SERVER/dictData/queryAllDictType`, params).then(res => res.data); };

//单个数据字典分类查询(所有)
export const getDictDataByType = params => { return _axios.post(`${base}/SPMS-SERVER/dictData/queryDictDataByType`, params).then(res => res.data); };

//单个数据字典分类查询(分页)
export const queryPageDictData = params => { return _axios.post(`${base}/SPMS-SERVER/dictData/queryPageDictData`, params).then(res => res.data); };

//单个数据字典分类新增
export const addDictData = params => { return _axios.post(`${base}/SPMS-SERVER/dictData/addDictData`, params).then(res => res.data); };

//单个数据字典分类修改
export const modifyDictData = params => { return _axios.post(`${base}/SPMS-SERVER/dictData/editDictData`, params).then(res => res.data); };

//单个数据字典分类删除
export const delDictData = params => { return _axios.post(`${base}/SPMS-SERVER/dictData/deleteDictData`, params).then(res => res.data); };