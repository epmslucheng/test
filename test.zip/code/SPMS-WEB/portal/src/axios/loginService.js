import {AxiosInstance} from './intercept';

let base=process.env.BASE_API;

let _axios = AxiosInstance(true);

// 用户登陆
export const loginService = params => { return _axios.post(`${base}/SPMS-SERVER/login`, params).then(res => res.data); };

//用户登出
export const logoutService = params => { return _axios.post(`${base}/SPMS-SERVER/logout`, params).then(res => res.data); };
