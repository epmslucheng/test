import {AxiosInstance} from './intercept';

let base=process.env.BASE_API;

let _axios = AxiosInstance(true);

// 系统日志列表
export const queryPageSysLog = params => { return _axios.post(`${base}/SPMS-SERVER/sysLog/queryPageSysLog`, params).then(res => res.data); };
