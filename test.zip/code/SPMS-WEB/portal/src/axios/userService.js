import {AxiosInstance} from './intercept';

let base=process.env.BASE_API;

let _axios = AxiosInstance(true);

// 获取用户列表
export const getUserList = params => { return _axios.post(`${base}/SPMS-SERVER/user/queryPageUser`, params).then(res => res.data); };

//新增用户
export const addUserInfo = params => { return _axios.post(`${base}/SPMS-SERVER/user/addUser`, params).then(res => res.data); };

//修改用户
export const modifyUserInfo = params => { return _axios.post(`${base}/SPMS-SERVER/user/editUser`, params).then(res => res.data); };

//重置用户密码
export const resetUserPassword = params => { return _axios.post(`${base}/SPMS-SERVER/user/editPwd`, params).then(res => res.data); };

//删除用户
export const deleteUserInfo = params => { return _axios.post(`${base}/SPMS-SERVER/user/deleteUser`, params).then(res => res.data); };

//授权用户
export const grantUserInfo = params => { return _axios.post(`${base}/SPMS-SERVER/user/grantUser`, params).then(res => res.data); };

//获取角色列表(分页)
export const getRoleList = params => { return _axios.post(`${base}/SPMS-SERVER/role/queryPageRole`, params).then(res => res.data); };

//获取角色列表(所有)
export const getAllRoleList = params => { return _axios.post(`${base}/SPMS-SERVER/role/queryAllRole`, params).then(res => res.data); };

//新增角色
export const addRoleInfo = params => { return _axios.post(`${base}/SPMS-SERVER/role/addRole`, params).then(res => res.data); };

//修改角色
export const modifyRoleInfo = params => { return _axios.post(`${base}/SPMS-SERVER/role/editRole`, params).then(res => res.data); };

//删除角色
export const deleteRoleInfo = params => { return _axios.post(`${base}/SPMS-SERVER/role/deleteRole`, params).then(res => res.data); };

//授权角色
export const grantRoleInfo = params => { return _axios.post(`${base}/SPMS-SERVER/role/grantRole`, params).then(res => res.data); };

//获取部门列表(分页)
export const getDeptList = params => { return _axios.post(`${base}/SPMS-SERVER/dept/queryPageDept`, params).then(res => res.data); };

//获取部门列表(所有)
export const getDeptAll = params => { return _axios.post(`${base}/SPMS-SERVER/dept/queryAllDepartments`, params).then(res => res.data); };

//新增部门
export const addDepartmentInfo = params => { return _axios.post(`${base}/SPMS-SERVER/dept/addDept`, params).then(res => res.data); };

//修改部门
export const modifyDepartmentInfo = params => { return _axios.post(`${base}/SPMS-SERVER/dept/editDept`, params).then(res => res.data); };

//删除部门
export const deleteDepartmentInfo = params => { return _axios.post(`${base}/SPMS-SERVER/dept/deleteDept`, params).then(res => res.data); };
