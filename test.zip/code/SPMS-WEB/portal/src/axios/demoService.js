import {AxiosInstance} from './intercept';

let base=process.env.BASE_API;

let _axios = AxiosInstance(true);

// 用户登陆
export const testPageQueryService = params => { return _axios.post(`${base}/SPMS-SERVER/testPageQuery`, params).then(res => res.data); };
