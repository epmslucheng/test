import axios from 'axios';
import { Loading,Message } from 'element-ui';
import i18n from '@/common/js/i18n' /** I18n国际化配置 **/
import Router from '@/common/js/router';/**引入路由js文件 **/

let _a = axios.create({headers: {'Content-Type': 'application/json'}});
let _b = axios.create({headers: {'Content-Type': 'application/x-www-form-urlencoded'}});
export const AxiosInstance = params => { return params ? _a : _b};
_a.interceptors.request.use(config => {
		if(config.url.indexOf("/login") < 0)
		{
			let token = sessionStorage.getItem('authorization');
			if (token) { config.headers['Authorization']=token; }
		}	
		return config;
	},
	error => {return Promise.reject(error);});
_a.interceptors.response.use(response => {return response;},
		error => {
			if(!error.response || error.response.status=='504')
			{
				Message.error({
					message:i18n.t('com.isoftchina.hes.login.timeout'),
					onClose:()=>{
						Router.push({path: '/login'});
					}
				});
			}	
			return Promise.reject(error);
		})