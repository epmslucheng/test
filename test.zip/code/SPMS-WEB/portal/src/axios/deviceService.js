import {AxiosInstance} from './intercept';

let base=process.env.BASE_API;

let _axios = AxiosInstance(true);

// 获取档案电表列表
export const getMeterList = params => { return _axios.post(`${base}/ICP/meter/queryPageMeter`, params).then(res => res.data); };

//新增电表
export const addMeter = params => { return _axios.post(`${base}/ICP/meter/addMeter`, params).then(res => res.data); };

//修改电表
export const editMeter = params => { return _axios.post(`${base}/ICP/meter/editMeter`, params).then(res => res.data); };

//删除电表
export const deleteMeter = params => { return _axios.post(`${base}/ICP/meter/deleteMeter`, params).then(res => res.data); };

//安装电表
export const meterInstall = params => { return _axios.post(`${base}/ICP/meter/meterInstall`, params).then(res => res.data); };

//拆除电表
export const meterRemove = params => { return _axios.post(`${base}/ICP/meter/meterRemove`, params).then(res => res.data); };

//获取设备维护列表
export const getMeterVoList = params => { return _axios.post(`${base}/ICP/meter/queryPageMeterVo`, params).then(res => res.data); };

//获取GPRS通讯信息
export const queryMeterCommPara = params => { return _axios.post(`${base}/ICP/meter/queryMeterCommPara`, params).then(res => res.data); };

//获取GPRS服务信息
export const queryMeterBussPara = params => { return _axios.post(`${base}/ICP/meter/queryMeterBussPara`, params).then(res => res.data); };

//数据树状查询
export const queryAttributeTree = params => { return _axios.post(`${base}/ICP/attribute/queryAttributeTree`, params).then(res => res.data); };

export const queryAttributeList = params => { return _axios.post(`${base}/ICP/attribute/queryAttributeList`, params).then(res => res.data); };

export const selectByPrimaryKey = params => { return _axios.post(`${base}/ICP/attribute/selectByPrimaryKey`, params).then(res => res.data); };

//数据召测
export const callData = params => { return _axios.post(`${base}/ICP/dataMgr/callData`, params).then(res => res.data); };

//数据下发
export const sendParam = params => { return _axios.post(`${base}/ICP/dataMgr/sendParam`, params).then(res => res.data); };