import {AxiosInstance} from './intercept';

let base=process.env.BASE_API;

let _axios = AxiosInstance(true);

// 用户登陆
export const menuAxios = params => { return _axios.post(`${base}/SPMS-SERVER/resource/queryAllResource`, params).then(res => res.data); };
