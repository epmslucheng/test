<template>
	<!-- <el-color-picker size="small" class="theme-picker" popper-class="theme-picker-dropdown" v-model="themeVal"></el-color-picker> -->
    <el-dropdown>
		    <span class="el-dropdown-link" style="padding:0 10px;cursor:pointer;"><i class="fa fa-cc"></i></span>
			<el-dropdown-menu slot="dropdown">
					<div class='p-5-10' :key="index" v-for="(item,index) in themes"><el-radio v-model="themeColor" :label="item.value">{{item.name}}</el-radio></div>
		      </el-dropdown-menu>
		  </el-dropdown>
</template>

<script>
import Theme from "@/common/js/theme";
import Config from "@/common/js/theme.json"
export default {
  name: "Theme",
  mixins: [Theme],
  data() {
    return {
      defaultTheme:Config.defaultTheme,
      themes:Config.themes
    };
  }
};
</script>

<style scoped>
.theme-picker .el-color-picker__trigger {
  vertical-align: middle;
}

.theme-picker-dropdown .el-color-dropdown__link-btn {
  display: none;
}
</style>