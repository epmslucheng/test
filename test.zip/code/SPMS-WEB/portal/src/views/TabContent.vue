<template>
</template>
<script>
	import Vue from 'vue';
	let $content=Vue.extend({
		template:'<tab :meta="meta" :param="param"></tab>'
	});
	export default {
		name: 'tabContent',
		props:['route'],
		mounted(){
			let component=this.route.component;
			let meta={children:this.route.children};
			let param=this.route.param;
			let el=this.$el;
			new $content({
				el:el,
				data() {
      			return {
      					meta:meta,
      					param:param
      				}
      			},
				components:{ 'tab':component }
			});
		}
	}

</script>

<style scoped>

</style>