<template>
	<section>
		<el-row  class="mt20">
			<el-col :span="6">&nbsp;</el-col>
			<el-col :span="12"><img :src="this.sysAvatar" v-if="sysAvatar" class="mt10"/><h1 class="hes-login--title">{{$t("com.isoftchina.hes.login.title")}}</h1></el-col>
			<el-col :span="6">&nbsp;</el-col>
		</el-row>
		<el-row  class="mt20 hes-login">
			<el-col :span="6">&nbsp;</el-col>
			<el-col :span="12" class="hes-login--center full-height">
  				<input type="password" name="password" style="display:none;" autocomplete="off"/><!-- 加一个隐藏的密码框，取消谷歌浏览器input自动填充密码 -->
				<el-form :model="ruleForm2" :rules="rules2" size="small" ref="ruleForm2" label-position="left" label-width="0px" class="hes-login--form">
				    <el-form-item prop="loginname">
				      <el-input @change="ruleForm2.password=null" type="text" v-model="ruleForm2.loginname" auto-complete="off" :placeholder="$t('com.isoftchina.hes.login.accountPlaceholder')" prefix-icon="fa fa-user" clearable></el-input>
				    </el-form-item>
				    <el-form-item prop="password">
				      <el-input type="password" @keyup.enter.native="handleSubmit2" v-model="ruleForm2.password" auto-complete="new-password" :placeholder="$t('com.isoftchina.hes.login.pwdPlaceholder')" prefix-icon="fa fa-lock" clearable></el-input>
				    </el-form-item>
				    <el-checkbox v-model="ruleForm2.rememberMe" class="remember">{{$t('com.isoftchina.hes.login.rememberPwd')}}</el-checkbox>
				    <el-form-item class="mt10 full-width">
				      <el-button type="primary" class="full-width" @click.native.prevent="handleSubmit2" :loading="logining">{{$t('com.isoftchina.hes.login.loginBtn')}}</el-button>
				    </el-form-item>
				    <el-form-item class="tc lang">
				      <a href="javascript:;" @click="changeLang('zh_CN')">中文</a>&nbsp;|&nbsp;<a href="javascript:;" @click="changeLang('en_US')">English</a>
				     </el-form-item>
				  </el-form>
			</el-col>
			<el-col :span="6">&nbsp;</el-col>
		</el-row>
		<el-row>
			<el-col :span="6">&nbsp;</el-col>
			<el-col :span="12" class="tc basic-font mt10">{{$t('com.isoftchina.hes.layout.footer.copyright')}}</el-col>
			<el-col :span="6">&nbsp;</el-col>
		</el-row>
	</section>
</template>

<script>
  import { loginService } from '@/axios/loginService.js';
  import Layout from '@/views/Layout.vue'
  import CryptoJS from 'crypto-js' //加密js
  import MixinRoutes from '@/router/routes.mixin' // 动态添加路由（采用混合模式进行异步加载）
  //import Theme from "@/common/js/theme";// 主题切换
  //import Config from "@/common/js/theme.json"// 主题切换
  export default {
    //mixins: [Theme],
    mixins: [MixinRoutes],
    data() {
      return {
        logining: false,
        //defaultTheme:Config.defaultTheme,// 主题切换
        sysAvatar:require('@/assets/logo-login.png'),
        ruleForm2: {
          loginname: '',
          password: '',
          rememberMe:true
        }
      };
    },
    mounted(){
        this.getCookie()
    },
    methods: {
     changeLang(lang){
     	this.$i18n.setLang(lang);
     },
      //设置cookie
	  setCookie(c_name,c_pwd,exdays) {
	    var exdate=new Date();//获取时间
	    exdate.setTime(exdate.getTime() + 24*60*60*1000*exdays);//保存的天数
	    //字符串拼接cookie
	    window.document.cookie="loginname"+ "=" +c_name+";path=/;expires="+exdate.toGMTString();
		let pwd = c_pwd ? CryptoJS.AES.encrypt(c_pwd, 'secret key 123') : '';//使用CryptoJS方法加密
		window.document.cookie="password"+"="+pwd+";path=/;expires="+exdate.toGMTString();
	  },
	  //读取cookie
	  getCookie:function () {
	    if (document.cookie.length>0) {
	      var arr=document.cookie.split('; ');//这里显示的格式需要切割一下自己可输出看下
	      for(var i=0;i<arr.length;i++){
	        var arr2=arr[i].split('=');//再次切割
	        //判断查找相对应的值
	        if(arr2[0]=='loginname'){
	          this.ruleForm2.loginname=arr2[1];//保存到保存数据的地方
	        }else if(arr2[0]=='password'){
	          let bytes = CryptoJS.AES.decrypt(arr2[1].toString(), 'secret key 123');
			  this.ruleForm2.password=bytes.toString(CryptoJS.enc.Utf8);
	        }
	      }
	    }
	  },
	  //清除cookie
	  clearCookie:function () {
	    this.setCookie("","",-1);//修改2值都为空，天数为负1天就好了
	  },
      handleReset2() {
        this.$refs.ruleForm2.resetFields();
      },
      handleSubmit2(ev) {
        var _this = this;
        this.$refs.ruleForm2.validate((valid) => {
          if (valid) {
            this.logining = true;
            loginService(this.ruleForm2).then(res => {
               this.logining = false;
               if(!res.success)
               {
               		this.logining = false;
               		this.$message({ message: this.$t('com.isoftchina.hes.login.loginError'), type: 'error' });
               		this.clearCookie();
               		return;
               }
               let user={
               	id:res.obj.id,
               	name:res.obj.name,
               	loginname:this.ruleForm2.loginname,
               	menuIds:res.obj.resourceIds,
               	status:res.obj.status,
               	sex:res.obj.sex,
               	phone:res.obj.phone,
               	email:res.obj.email
               	};
               sessionStorage.setItem('user', JSON.stringify(user));
               sessionStorage.setItem('authorization', res.obj.authorization);
               // 登陆成功后，判断用户是否是首次登陆系统
               if(res.obj.pwdFirstUpdate==='0')
               {	
               		_this.$router.push({ path: '/resetPassword' });
               		this.setCookie(this.ruleForm2.loginname,null,7)
                	return;
               }
               this.initMenu();// 登陆成功后加载菜单路由
               _this.$router.push({ path: '/main' });
               //判断复选框是否被勾选 勾选则调用配置cookie方法
               this.ruleForm2.rememberMe ? this.setCookie(this.ruleForm2.loginname,this.ruleForm2.password,7) : this.clearCookie();
            }).catch(error => {
            	this.logining = false;
            });
          }
        });
      }
    },
    computed:{
    	 rules2(){
          return {
          	  loginname: [
	            { required: true, message: this.$i18n.t("com.isoftchina.hes.login.accountPlaceholder"), trigger: 'blur' }
	          ],
	          password: [
	            { required: true, message: this.$i18n.t("com.isoftchina.hes.login.pwdPlaceholder"), trigger: 'blur' }
	          ]
          }
        }
    }
  }
</script>