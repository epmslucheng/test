<template>
	<el-container class="full-height layout" v-loading="loading">
		<el-header class="header" height="50px">
			<el-row class="layout_width">
				<el-col :span="3"><img :src="this.sysAvatar" v-if="sysAvatar" class="mt10"/></el-col>
				<el-col :span="11">
					<span>&nbsp;</span>
					<span  v-for="(menu,index) in menuList" v-if="!menu.hidden" :key="index">
						<span class="link menu" :class="itemActive.path==(menu.children.length ? menu.children[0].path : '') ? 'menu-active':''" v-if="menu.isLeaf" @click="routerTo(menu.children[0])">{{$t(menu.i18nKey)}}</span>
						<el-dropdown placement="bottom-start" class="menu" v-else>
					      <span class="link" :class="menuActive.path==menu.path ? 'menu-active':''">{{$t(menu.i18nKey)}}</span>
					      <el-dropdown-menu slot="dropdown" class="menu-dropdown">
					      		<div class="menu-item" v-for="(menuItem,itemIndex) in menu.children" :key="itemIndex">
						      		 <span class="menu-item-title">{{$t(menuItem.i18nKey)}}</span>
						      		 <el-dropdown-item :class="itemActive.path==route.path ? 'menu-active':''" v-for="(route,routeIndex) in menuItem.children" :key="routeIndex" 
						      		 		@click.native.stop="routerTo(route)">{{$t(route.i18nKey)}}</el-dropdown-item>
					      		</div>
						  </el-dropdown-menu>
					    </el-dropdown>
					</span>
				</el-col>
				<el-col :span="10">
					<div class="control">
						<span class="alarm-list">
							<i class="alarm-critical" aria-hidden="true" :title="$t('com.isoftchina.hes.layout.header.menu.critical') + ':' + 1"><em>1</em></i>
							<i class="alarm-major" aria-hidden="true" :title="$t('com.isoftchina.hes.layout.header.menu.major') + ':' + 3"><em>3</em></i>
							<i class="alarm-minor" aria-hidden="true" :title="$t('com.isoftchina.hes.layout.header.menu.minor') + ':' + 3"><em>3</em></i>
							<i class="alarm-warning" aria-hidden="true" :title="$t('com.isoftchina.hes.layout.header.menu.warning') + ':' + 3"><em>3</em></i>
						</span>
						<span class="sep"></span>
						<span>
							<el-badge :value="3" class="hes-badge">
							  <i class="fa fa-wpforms" aria-hidden="true" :title="$t('com.isoftchina.hes.layout.header.workorder')"></i>
							</el-badge>
						</span>
						<span style="position:relative;top:-2px;">{{$t("com.isoftchina.hes.layout.header.welcome")}}, {{sysUserName}}</span>
						<span><i class="fa fa-sign-out" aria-hidden="true" :title="$t('com.isoftchina.hes.layout.header.exit')" @click="()=>logout()"></i></span>
						<span class="sep"></span>
						<!-- <span><i class="fa fa-question" aria-hidden="true" :title="$t('com.isoftchina.hes.layout.header.help')"></i></span>-->
						<span>
							<el-dropdown placement="bottom-end" class="hes-drop" @command="openPerson">
						      <i class="fa fa fa-user" aria-hidden="true"></i>
						      <el-dropdown-menu slot="dropdown" class="hes-dropdown">
						      		<el-dropdown-item v-for="(l,index) in hurdle" :command="l.value" :key="index">
						      			<span style="padding:0 3px;display:inline-block;">{{$t(l.label)}}</span>
						      		</el-dropdown-item>
						      </el-dropdown-menu>
						    </el-dropdown>
						</span>
						<span><i class="fa fa-info" aria-hidden="true" :title="$t('com.isoftchina.hes.layout.header.about')" @click="aboutVisible=true"></i></span>
						<span>
							<el-dropdown placement="bottom-end" class="hes-drop" @command="language">
						      <i class="fa fa-globe" aria-hidden="true" :title="$t('com.isoftchina.hes.layout.header.i18nTitle')"></i>
						      <el-dropdown-menu slot="dropdown" class="hes-dropdown">
						      		<el-dropdown-item v-for="(l,index) in languages" :command="l.lang" :key="index">
						      			<span style="width:60px;padding:0 3px;display:inline-block;">{{l.label}}</span>
						      			<i v-if="$i18n.locale==l.lang" class="fa fa-check-square-o"></i>
						      		</el-dropdown-item>
						      </el-dropdown-menu>
						    </el-dropdown>
						</span>
					</div>
				</el-col>
			</el-row>
		</el-header>
		<el-main class="main bg">
			<el-row class="layout_width full-height">
				<el-container class="full-height">
					  <el-aside width="240px" v-if="leftMenu && !itemActive.isLeaf" class="mtb5">
						  	<el-menu :default-active="itemActive.i18nKey" class="left-menu full-height">
						  	  <span class="left-menu-title">
						  	  	<i class="fa fa-bars" aria-hidden="true"></i>
						  	  	<span>{{$t(leftMenu.i18nKey)}}</span>
						  	  </span>
						      <el-menu-item :index="item.i18nKey" v-for="(item,index) in leftMenu.children" :key="item.i18nKey" @click.native="routerTo(item)">
						        <span>{{$t(item.i18nKey)}}</span>
						      </el-menu-item>
						    </el-menu>
					  </el-aside>
					  <el-container class="mtb5">
					    <el-header class="nav-header">
					    	<el-breadcrumb separator-class="el-icon-arrow-right">
							  <el-breadcrumb-item v-if="menuActive.i18nKey" :class="menuActive.i18nKey &&  !itemActive.i18nKey? 'menu-active' : ''">{{$t(menuActive.i18nKey)}}</el-breadcrumb-item>
							  <el-breadcrumb-item v-if="centerActive.i18nKey">{{$t(centerActive.i18nKey)}}</el-breadcrumb-item>
							  <el-breadcrumb-item v-if="itemActive.i18nKey" :class="itemActive.i18nKey ? 'menu-active' : ''">{{$t(itemActive.i18nKey)}}</el-breadcrumb-item>
							</el-breadcrumb>
					    </el-header>
					    <el-main class="main bg-white">
					    		<router-view></router-view>
					    </el-main>
					  </el-container>
			  </el-container>
			</el-row>
		</el-main>
		<el-footer height="30px" class="footer">
			<el-row class="layout_width">
				<div class="tc mt5">{{$t('com.isoftchina.hes.layout.footer.copyright')}}</div>
			</el-row>
		</el-footer>
		<el-model v-if="visible" :visible.sync="visible" :title="$t('com.isoftchina.hes.layout.header.person')" width="750px" @ok-click="submitInfo">
			<user-info :data="info" :config="config"></user-info>
		</el-model>
		<el-model v-if="pwdVisible" :visible.sync="pwdVisible" :title="$t('com.isoftchina.hes.layout.header.modifypwd')" width="550px" @ok-click="submitPwdInfo">
			<password :pwdForm="info"></password>
		</el-model>
		<el-model v-if="aboutVisible" :visible.sync="aboutVisible" :title="$t('com.isoftchina.hes.layout.header.about')" width="500px" :show-btn="false">
			<el-row style="padding:20px 0;">
				<el-col :span="10">
					<div class="hes-about--logo">
						<img :src="this.sysAvatar" v-if="sysAvatar" style="margin-top:50px;"/>
					</div>
				</el-col>
				<el-col :span="14">
					<div class="hes-about">HES</div>
					<div>Version: HESV100R001C05LA001B001</div>
					<div>Build ID: 20181022-001</div>
					<div>STS Certificate No:STS 637</div>
					<div>© 2019 HES. All rights reserved.</div>
				</el-col>
			</el-row>
		</el-model>
	</el-container>
</template>
<script>
    import * as systemService from '@/axios/systemService';
    import { logoutService } from '@/axios/loginService.js';
    import * as paramsService from '@/axios/paramsService';
    import * as userService from '@/axios/userService';
    import MixinRoutes from '@/router/routes.mixin' // 动态添加路由（采用混合模式进行异步加载）
    import UserInfo from '@/views/service/administrator/administrator/dialog/UserInfo';
    import Password from '@/views/service/administrator/administrator/dialog/Password';
	export default {
		mixins: [MixinRoutes],
		data() {
			return {
				loading:false,
				sysAvatar:require('@/assets/logo.png'),
				sysUserName:"",
				menuActive:{},
				centerActive:{},
				menuList:[],
				leftMenu:null,
				visible:false,
				pwdVisible:false,
				aboutVisible:false,
				info:{},
				config:{},
				authority:false,
				itemActive:{i18nKey:'com.isoftchina.hes.layout.header.menu.home',path:'/home'},
				languages:[{label:'中文',lang:'zh_CN'},{label:'English',lang:'en_US'}],
				hurdle:[{label:'com.isoftchina.hes.layout.header.person',value:0},{label:'com.isoftchina.hes.layout.header.modifypwd',value:1}],
			}
		},
		methods:{
			openPerson(d){
				let user=JSON.parse(sessionStorage.getItem('user'));
				if(d===0){
					this.info=user;
					this.$set(this.info,"sex",String(this.info.sex));
					this.config.filterable=true;
					// 性别
		   			paramsService.getDictDataByType("sex").then(res=>{ this.$set(this.config,'sexMenu',res.obj); })
		   			// 状态
		   			paramsService.getDictDataByType("status").then(res=>{ this.$set(this.config,'statusMenu',res.obj); })
					this.visible=true;
				}
				else if(d===1)
				{
					this.info={id:user.id};
					this.pwdVisible=true;
				}
			},
			submitInfo(){
				userService.modifyUserInfo(this.info).then(res=>{
					this.$message({ showClose: true, message: (res.success ? this.$t('com.isoftchina.hes.common.success') : this.$t('com.isoftchina.hes.common.fail')), type: (res.success ? 'success' : 'error') });
					this.visible=false;
				});
			},
			submitPwdInfo(){
    			userService.resetUserPassword({id:this.info.id,newPwd:this.info.password,oldPwd:this.info.oldPassword}).then(res=>{
					this.$message({
						showClose: false,
						message: (res.success ? this.$t('com.isoftchina.hes.login.resetpassword.success')  : this.$t('exception.'+res.resultCode)),
						type: (res.success ? 'success' : 'error'),
						onClose:()=>{
							if(res.success)logoutService({}).then(response=>{ if(response.success) this.$router.push('/login');});
						}});
    				this.pwdVisible=false;
    			});
			},
			routerTo(menu){
				if(menu)
				{
					if(this.authority){
						this.itemActive=menu;
						let match=this.$router.match(menu.path);
						let parents=match.matched.map(r=>{ r.i18nKey=(r.name ? r.name.split('-')[0] : null); return r;});
						this.menuActive=parents[0] ? parents[0] : this.itemActive;
						this.centerActive=parents[1] || {};
						this.leftMenu=this.$root.menuBasicList.filter(basicMenu=>basicMenu.menuId==menu.parentId)[0];
						this.$router.push(menu.path);
					}
					return;
				}
				this.$router.push("/404");
			},
			language(lang){
				this.$i18n.setLang(lang);
			},
			filterMenuList(list,menuIds){
				let sourceRoutes=this.$router.options.sourceRoutes.map(r=>{ r.i18nKey=r.name; return r;});
				return sourceRoutes.concat(this.$utils.listToTree("menuId","parentId",list.filter(r=>{delete r.children; return (menuIds || []).indexOf(String(r.menuId)) > -1;})));
			},
			logout(){
				var _this = this;
				_this.$confirm(this.$t("com.isoftchina.hes.layout.header.enquireExit"), this.$t("com.isoftchina.hes.layout.header.tip"), {
					type: 'warning'
				}).then(() => {
					setTimeout(()=>{
						logoutService({}).then(res=>{ if(res.success) _this.$router.push('/login');this.loading=false;});
					},50);
				}).catch(() => {
				});
			}
		},
		mounted() {
			this.$router.push(this.itemActive.path);
			let user = sessionStorage.getItem('user');
			if (user) {
				user = JSON.parse(user);
				this.sysUserName=user.name;
				this.authority=(user.menuIds && user.menuIds.length);
				this.initMenu();
				this.$root.eventHub.$on("menuBasicList",n=>{ this.menuList=this.filterMenuList(n,user.menuIds);}); 
				this.authority ? this.$router.push({ path:'/home'}) : this.$router.push({path:'/noAuthority'});
			}	
		},
		components: {
		  UserInfo,
		  Password
	    }
	}
</script>
<style lang="scss">
	@import '~scss_vars';
</style>