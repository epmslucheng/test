<template>
	<section>
		<div class="vue-select" v-clickoutside="handleClickOutSide">
				<label  :title="inputText">
  					<el-input :placeholder="$t('com.isoftchina.hes.common.pleaseSelect')" v-model="inputValue" node-key="value" size="mini" :suffix-icon="isShowSelect ? 'el-icon-arrow-up is-reverse' : 'el-icon-arrow-up'" readonly="readonly" 
  							   @click.native.stop="showTree"></el-input>
					<span class="vue-select-label--mini">{{inputText}}</span>
  				</label>			   
  				<transition name="el-zoom-in-top">
	  				<div v-if="isShowSelect" class="select-tree">
		  				<div class="select-tree-body">
		  				<el-scrollbar>
					        <el-tree :data="data" :props="props" default-expand-all ref="selectTree"
					        			 :expand-on-click-node="false" 
					        			 :check-strictly="true"
					        			 :check-on-click-node="true" 
					        			 :show-checkbox="true" 
					        			 :node-key="props.value"
					        			 :filter-node-method="filterNode"
					        			 @check="handleNodeClick"
					        			 :default-checked-keys="defaultCheckedKeys"
					        			 ></el-tree>
				        </el-scrollbar>
					    </div>
				    </div>
			    </transition>
		   </div>
	</section>
</template>
<script>
  export default {
  	model: {
      prop: 'inputValue',
      event: 'treeNode'
    },
    props:["data","props","inputValue",'multiselect'],
  	data() {
      return {
      	isShowSelect:false,
      	inputText:"",
      	defaultCheckedKeys:[]
      }
    },
    methods: {
    	showTree(e){
			if(e.currentTarget.classList.contains('is-disabled'))return;
    		this.isShowSelect=!this.isShowSelect
    	},
    	handleClickOutSide(e) {
    		this.isShowSelect=false;
    	},
    	filterNode(value, data){
    		this.$emit("filter",value, data);
    	},
    	handleNodeClick(data,check) {
    		if(!this.multiselect)
    		{
    			let isChecked = this.$refs.selectTree.getCheckedKeys().length;
    			this.$refs.selectTree.setCheckedNodes(isChecked ? [data] : []);
    		}
    	    let selectedNodes = this.$refs.selectTree.getCheckedNodes();
    		let selectedNodeKeys=[];
    		let selectedNodeLabels=[];
    		selectedNodes.forEach(node=>{
    			selectedNodeKeys.push(node[this.props.value]);
    			selectedNodeLabels.push(node[this.props.label]);
    		});
    		this.$emit('treeNode', selectedNodeKeys.join(","));
    		this.$emit('check',this.multiselect ? selectedNodes : (selectedNodes.length ? selectedNodes[0] : undefined));
    		this.inputText=selectedNodeLabels.join(",");
      	}
    },
    watch: {
	    isShowSelect: function(curVal,oldVal){
		    //初始话下拉框的值
	        this.defaultCheckedKeys=[];
	        let array=this.inputValue ? this.inputValue.toString().split(",") : [];
	        for(let i=0;i<array.length;i++) {this.defaultCheckedKeys.push(parseInt(array[i]));}
	    },
	    inputValue:function(n,o){
	    	if(!n)this.inputText='';
	    }
	},
    mounted(){
    	let key=this.props ? this.props['label'] : 'label';
    	let value=this.props ? this.props['value'] : 'value';
	    this.inputText=this.$utils.getLabelByValue(this.data,{key:key,value:value},this.inputValue);
    }
  };
</script>