<template>
	<section class="full-height full-width">
		<el-dropdown class="fr mb5" v-if="showColumnSetting">
		    <el-button size="mini" icon="fa fa-list-ul">{{$t('com.isoftchina.hes.common.columnSetting')}}</el-button>
			<el-dropdown-menu slot="dropdown">
				    <div class='p-5-10' :key="index" v-for="(item,index) in columns"><el-checkbox v-model="item.visible" :label="$t(item.label)"></el-checkbox></div>
		      </el-dropdown-menu>
	    </el-dropdown>
		<el-table @row-click="handleRowClick" @selection-change="selsChange" 
						:row-key="uniqueKey"
						@row-dblclick="handleDbRowClick"
						:data="data" :height="calcHeight" class="vue-table"
					    :show-summary="showSummary" :summary-method="summaryMethod" :highlight-current-row="highlightCurrentRow"
					    :row-class-name="tableRowClassName">
			<el-table-column type="selection" :reserve-selection="reserveSelection" :selectable='checkboxT' width="60" fixed v-if="showCheckbox" align="center"></el-table-column>
			<el-table-column type="index" width="60" fixed v-if="showRowNumber" align="center" :label="$t('com.isoftchina.hes.common.no')"></el-table-column>
			<el-table-column :label="$t('com.isoftchina.hes.common.operation')" align="center" width="120" fixed v-if="showOperation && operationColumn" v-permissions:delete,edit,view="{fn:permission}">
		      <template slot-scope="{row,$index}">
		        <el-button v-permissions:delete v-if="showColumnDel" type="text" size="mini" @click.stop="() => remove($event,row)"><i class="el-icon-delete"></i></el-button>
		        <el-button v-permissions:edit v-if="showColumnEdit" type="text" size="mini" @click.stop="() => edit($event,row)"><i class="el-icon-edit-outline"></i></el-button>
		        <el-button v-permissions:view v-if="showColumnView" type="text" size="mini" @click.stop="() => edit($event,row,true)"><i class="el-icon-view"></i></el-button>
		      </template>
		    </el-table-column>
		    <slot></slot>
		    <el-table-column :align="item.align" show-overflow-tooltip v-if="item.visible" :key="index" v-for="(item,index) in columns" :prop="item.prop" :label="$t(item.label)" :min-width="item.width" :sortable="item.sortable">
		    	<template slot-scope="{row,column}">
		    		<span  v-if="item.type=='text'">
		    			<el-input size="mini" v-model="row[item.prop]"></el-input>
		    		</span>
		    		<span  v-if="item.type=='number'">
		    			<el-input-number size="mini" v-model="row[item.prop]" :controls="false"></el-input-number>
		    		</span>
		    		<span v-else>
		    			<span :class="item.className">{{fomatMethod(row,column,row[item.prop])}}</span>
		    		</span>
		    	</template>
		    </el-table-column>
		  </el-table>
	</section>
</template>
<script>
  export default {
    props:{
    	data: {
	      type: Array,
	      default: () => []
	    },
	    height:{
	     type:String,
	     default:''
	    },
	    uniqueKey:{
	     type:String,
	     default:'id'
	    },
	    reserveSelection:{
    	  type:Boolean,
    	  default:false
    	},
	    selectTable:{
	     type:String,
	     default:'disabled'
	    },
	    columns: {
	      type: Array,
	      default: () => []
	    },
    	formatter:{
    	  type:Function,
    	  default:(row, column,value)=>{return value}
    	},
    	showCheckbox:{
    	  type:Boolean,
    	  default:true
    	},
    	showRowNumber:{
    	  type:Boolean,
    	  default:true
    	},
    	showOperation:{
    	  type:Boolean,
    	  default:true
    	},
    	showColumnSetting:{
    	  type:Boolean,
    	  default:true
    	},
    	showSummary:{
    	  type:Boolean,
    	  default:false
    	},
    	showColumnDel:{
    		type:Boolean,
    	  	default:true
    	},
    	showColumnEdit:{
    		type:Boolean,
    	  	default:true
    	},
    	showColumnView:{
    		type:Boolean,
    	  	default:true
    	},
    	summaryMethod:{
    		type:Function,
    	  	default:()=>{}
    	},
    	highlightCurrentRow:{
    		type:Boolean,
    	  	default:false
    	}
    },
  	data() {
      return {
      	operationColumn:true,
      	sels:[]
      }
    },
    methods: {
    	permission(h){
    		this.operationColumn=h;
    	},
    	fomatMethod(row,column,value){
    		return this.formatter(row,column,value);
    	},
    	tableRowClassName({row, rowIndex}) {
	          return rowIndex % 2 == 0 ? 'odd-row' : 'even-row';
	    },
	    checkboxT(row,index){
	    	return row[this.selectTable] ? 0 : 1;
    	},
    	selsChange(sels) {
	        //被选中的行组成数组 
	        this.sels=[];
	        sels.forEach(sel => {this.sels.push(sel[this.uniqueKey])});
	        this.$emit('getCheckedRows', this.sels);
	        this.$emit('getSelectedRows', sels);
      },
      remove(event,row){
      	this.$emit('rowRemove', event, row);
      },
      edit(event,row,isView){
      	this.$emit('rowEdit', event, row,isView);
      },
      handleRowClick(row, event, column){
      	this.$emit('row-click', row, event, column);
      },
      handleDbRowClick(row,event,column){
      	this.$emit('row-dblclick', row, event, column);
      }
    },
    computed:{
    	calcHeight(){
    		if(this.height)return this.height;
    		return this.showColumnSetting ? 'calc(100% - 38px)' : '100%';
    	}
    }
  };
</script>