<template>
		<el-container class="full-height layout">
		<el-header height="60px">
			<el-row class="layout_width">
				<el-col :span="3">&nbsp;</el-col>
				<el-col :span="21" class="mt20 red" style="font-weight:bolder;font-size:16px;">
					{{$t('com.isoftchina.hes.login.resetpassword')}}
				</el-col>
			</el-row>
		</el-header>
		<el-main class="main bg">
			<el-row class="full-height">
				<el-row  class="hes-login">
					<el-col :span="4">&nbsp;</el-col>
					<el-col :span="12" class="hes-login--center full-height">
						<el-form :model="pwdForm" size="small" ref="pwdForm" label-position="left" label-width="140px" class="hes-login--form" :rules="rules">
							<el-form-item :label="$t('com.isoftchina.hes.login.resetpassword.account')" class="account-label">
						      <div class="account">{{pwdForm.loginname}}</div>
						    </el-form-item>
						    <el-form-item prop="oldPassword" :label="$t('com.isoftchina.hes.login.resetpassword.old')">
						      <el-input type="password" v-model="pwdForm.oldPassword" auto-complete="new-password" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter')+$t('com.isoftchina.hes.login.resetpassword.old')" clearable></el-input>
						    </el-form-item>
						    <el-form-item prop="password" :label="$t('com.isoftchina.hes.login.resetpassword.new')">
						      <el-input type="password" v-model="pwdForm.password" auto-complete="new-password" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter')+$t('com.isoftchina.hes.login.resetpassword.new')" clearable></el-input>
						    </el-form-item>
						    <el-form-item prop="confirmPassword" :label="$t('com.isoftchina.hes.login.resetpassword.confirm')">
						      <el-input type="password" v-model="pwdForm.confirmPassword" auto-complete="new-password" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter')+$t('com.isoftchina.hes.login.resetpassword.confirm')" clearable></el-input>
						    </el-form-item>
						    <el-button type="primary" :disabled="disabled" :loading="loading" class="mt10 full-width submit-btn" @click.native.stop="()=>submit()">{{$t('com.isoftchina.hes.common.submit')}}</el-button>
						  </el-form>
					</el-col>
					<el-col :span="8" class="full-height">
						<div style="padding:55px 0 40px 0;">
							<ul class="req mt10">
								<li class="req-title">{{$t('com.isoftchina.hes.common.reqTitle')}}</li>
								<li>01.&nbsp;{{$t('com.isoftchina.hes.common.req1')}}</li>
								<li>02.&nbsp;{{$t('com.isoftchina.hes.common.req2')}}</li>
								<li>03.&nbsp;{{$t('com.isoftchina.hes.common.req3')}}</li>
								<li>04.&nbsp;{{$t('com.isoftchina.hes.common.req4')}}</li>
								<li>05.&nbsp;{{$t('com.isoftchina.hes.common.req5')}}</li>
								<li>06.&nbsp;{{$t('com.isoftchina.hes.common.req6')}}</li>
								<li>07.&nbsp;{{$t('com.isoftchina.hes.common.req7')}}</li>
							</ul>
						</div>
					</el-col>
				</el-row>
				<el-row>
					<div class="tc mt5">{{$t('com.isoftchina.hes.layout.footer.copyright')}}</div>
				</el-row>
			</el-row>
		</el-main>
	</el-container>
</template>
<script>
  import { logoutService } from '@/axios/loginService.js';
  import * as userService from '@/axios/userService';
  export default {
    data() {
     let validateLoginName = (rule, value, callback) => {
	    	if(value==this.pwdForm.loginname) { callback(new Error(rule.message)); return;  }
			callback();
		};
      let validatePass = (rule, value, callback) => {
	    	if(value==this.pwdForm.oldPassword) { callback(new Error(rule.message)); return;  }
	    	if(this.pwdForm.confirmPassword) { this.$refs.pwdForm.validateField('confirmPassword'); }
			callback();
		};
	  let validatePass2 = (rule, value, callback) => { if (value != this.pwdForm.password) { callback(new Error(rule.message)); } else { callback(); } };
	  let user=JSON.parse(sessionStorage.getItem('user'));
      return {
      	sysAvatar:require('@/assets/logo.png'),
      	loading:false,
      	disabled:false,
      	pwdForm:{id:user.id,loginname:user.name},
      	rules:{ 
	    	oldPassword:[ 
	    							{required: true, message: this.$t('com.isoftchina.hes.login.resetpassword.old') + this.$t('com.isoftchina.hes.common.notnull')}
	    						],
	    	password:[ 
	    							{required: true, message: this.$t('com.isoftchina.hes.login.resetpassword.new') + this.$t('com.isoftchina.hes.common.notnull')},
	    							{validator: validateLoginName, message: this.$t('com.isoftchina.hes.common.req1'),trigger: 'blur'},
	    							{validator: this.$validate.checkPassword, trigger: 'blur'},
	    							{validator: validatePass,message:this.$t('com.isoftchina.hes.common.req2'),trigger: 'blur'}
	    						],
	    	confirmPassword:[ 
	    							{required: true, message: this.$t('com.isoftchina.hes.login.resetpassword.confirm') + this.$t('com.isoftchina.hes.common.notnull')},
	    							{validator: validatePass2,message: this.$t('com.isoftchina.hes.common.req8'),trigger: 'blur'}
	    						]									
	    }
      };
    },
    mounted() {
    	sessionStorage.removeItem("user");
    },
    methods: {
    	submit(){
    		this.$refs.pwdForm.validate((valid) => {
    			if(!valid)return;
    			let param={id:this.pwdForm.id,newPwd:this.pwdForm.password,oldPwd:this.pwdForm.oldPassword};
    			this.logining = true;
    			this.disabled = true;
    			userService.resetUserPassword(param).then(res=>{
    				this.logining = false;
    				this.disabled=res.success;
					this.$message({
						showClose: false,
						message: (res.success ? this.$t('com.isoftchina.hes.login.resetpassword.success')  : this.$t('exception.'+res.resultCode)),
						type: (res.success ? 'success' : 'error'),
						onClose:()=>{
							if(res.success)logoutService({}).then(response=>{ if(response.success) this.$router.push('/login');});
						}});
    			});
    		});
    	}
    }
  }
</script>
<style lang="scss" scoped>
	.hes-login--form{border:none;box-shadow: none;border-radius: 0;width: 480px;padding: 55px 55px 40px 34px}
	.submit-btn{ border-radius: 0; padding: 8px 20px; }
	.account{border-radius: 4px;border: 1px solid #DCDFE6;background-color: #FFF;height: 30px;line-height: 30px;padding: 0 15px;color: #606266;}
	.req{
	 color:#fff;
	 list-style:none;
	 width:400px;
	 padding:0;
	 li{ 
	 	padding:8px;
	 	white-space: nowrap;
	  }
	  .req-title{border-bottom:1px solid #DCDFE6;padding:16px 8px;font-size:14px;}
	}
</style>