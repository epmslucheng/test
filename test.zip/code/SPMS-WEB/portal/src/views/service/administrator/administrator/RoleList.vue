<template>
		<el-container class="page-container">
		  <el-header height="70px">
			<el-form class="vue-form mt20" :model="data" size="mini">
			<el-row>
				<el-col :span="24">
				  	<el-row>
				  		<el-col :span="7">
				  			<el-form-item :label="$t('com.isoftchina.hes.common.role.name')" :label-width="formLabelWidth">
						      <el-input v-model="data.name" autocomplete="off" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + $t('com.isoftchina.hes.common.role.name')" clearable></el-input>
						    </el-form-item>
				  		</el-col>
				  		<el-col :span="7">
				  			<el-form-item :label="$t('com.isoftchina.hes.common.role.stauts')" :label-width="formLabelWidth">
						      <el-select v-model="data.status" :placeholder="$t('com.isoftchina.hes.common.pleaseSelect')">
							    <el-option v-for="item in config.statusMenu" :key="item.value" :label="$t('static.'+item.codeType+'_'+item.value)" :value="item.value"></el-option>
							  </el-select>
						    </el-form-item>
				  		</el-col>
				  		<el-col :span="2">&nbsp;</el-col>
				  		<el-col :span="7">
				  			<el-button type="primary" icon="fa fa-search" size="mini" @click.native="()=>getDataList()">{{$t('com.isoftchina.hes.common.query')}}</el-button>
				  			<el-button size="mini" icon="fa fa-eraser" @click.native="()=>reset()">{{$t('com.isoftchina.hes.common.reset')}}</el-button>
				  		</el-col>
				  	</el-row>
				</el-col>
			</el-row>
		  </el-form>
		</el-header>
		<el-main>
			<div class="full-screen" v-loading="loading">
				<div style="position:absolute;">
		  			<el-button type="primary" size="mini" icon="fa fa-plus" @click.stop="()=>operationInfo()">{{$t('com.isoftchina.hes.common.add')}}</el-button>
				    <el-button size="mini" icon="fa fa-trash" @click.stop="()=>remove()">{{$t('com.isoftchina.hes.common.del')}}</el-button>
		  		</div>
			    <el-grid :data="dataList" :columns="columns" :show-operation="false" @getCheckedRows="getCheckedRows" :formatter="formatter">
			    	<el-table-column :label="$t('com.isoftchina.hes.common.operation')" width="160" fixed align="center">
					      <template slot-scope="{row,$index}">
					      		<el-tag size="mini" :disable-transitions="true" class="vue-tag" @click.native="()=>operationInfo(row)">{{$t('com.isoftchina.hes.common.modify')}}</el-tag>
					        	<el-tag size="mini" :disable-transitions="true" class="vue-tag" @click.native="()=>openMenuSet(row)">{{$t('com.isoftchina.hes.common.role.resources')}}</el-tag>
					      </template>
				    </el-table-column>
			    </el-grid>
			</div>
		</el-main>
		<el-footer height="40px">
			<el-pagination background :layout="layout" class="fr" 
									:total="total" 
	    							:page-sizes="pageSizes" 
	    							:page-size="page.pageSize" 
	    							:current-page="page.pageNo" 
									@size-change="sizeChange"
									@current-change="currentChange"></el-pagination>
		</el-footer>
		<el-model v-if="visible" :visible.sync="visible" :title="(isAdd ? $t('com.isoftchina.hes.common.add') : $t('com.isoftchina.hes.common.modify')) + $t('com.isoftchina.hes.common.role')" width="750px" @ok-click="submitInfo">
			<role-info :data="info" :config="config"></role-info>
		</el-model>
		<el-model v-if="menuVisible" :visible.sync="menuVisible" :title="$t('com.isoftchina.hes.common.role.resources')" width="450px" @ok-click="submitMenuRelation">
			<menu-relation :data="menuRelation"></menu-relation>
		</el-model>
	</el-container>
</template>
<script src="./js/RoleList.js"></script>