<template>
	<el-container class="page-container">
		  <el-header height="60px">
			<el-form class="vue-form mt20" :model="data" size="mini">
			<el-row>
				<el-col :span="24">
				  	<el-row>
				  		<el-col :span="7">
				  			<el-form-item :label="$t('com.isoftchina.hes.common.params.moudle')" :label-width="formLabelWidth">
							     <el-select v-model="data.module" :placeholder="$t('com.isoftchina.hes.common.pleaseSelect')" filterable>
								    <el-option v-for="item in mouduleList" :key="item" :label="item" :value="item"></el-option>
								  </el-select>
						    </el-form-item>
				  		</el-col>
				  		<el-col :span="1">&nbsp;</el-col>
				  		<el-col :span="7">
				  			<el-form-item :label="$t('com.isoftchina.hes.common.params.name')" :label-width="formLabelWidth">
						      <el-input v-model="data.name" autocomplete="off" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + $t('com.isoftchina.hes.common.params.name')" clearable></el-input>
						    </el-form-item>
				  		</el-col>
				  		<el-col :span="2">&nbsp;</el-col>
				  		<el-col :span="6">
				  			<el-button type="primary" icon="fa fa-search" size="mini" @click.native="()=>getDataList()">{{$t('com.isoftchina.hes.common.query')}}</el-button>
				  			<el-button size="mini" icon="fa fa-eraser" @click.native="()=>reset()">{{$t('com.isoftchina.hes.common.reset')}}</el-button>
				  		</el-col>
				  	</el-row>
				</el-col>
			</el-row>
		  </el-form>
		</el-header>
		<el-main>
			<div class="full-screen" v-loading="loading">
			    <el-grid :data="dataList" :columns="columns" :show-checkbox="false" :show-operation="false">
			    	<el-table-column :label="$t('com.isoftchina.hes.common.operation')" width="100" fixed align="center">
					      <template slot-scope="{row,$index}">
					      		<el-tag size="mini" :disable-transitions="true" class="vue-tag" @click.native="()=>operationInfo(row)">{{$t('com.isoftchina.hes.common.modify')}}</el-tag>
					      </template>
				    </el-table-column>
			    </el-grid>
			</div>
		</el-main>
		<el-footer height="40px">
			<el-pagination background :layout="layout" class="fr" 
									:total="total" 
	    							:page-sizes="pageSizes" 
	    							:page-size="page.pageSize" 
	    							:current-page="page.pageNo" 
									@size-change="sizeChange"
									@current-change="currentChange"></el-pagination>
		</el-footer>
		<el-model v-if="visible" :visible.sync="visible" :title="$t('com.isoftchina.hes.common.modify')" width="750px" @ok-click="submitInfo">
			<param-info :data="info"></param-info>
		</el-model>
	</el-container>
</template>
<script src="./js/SystemParams.js"></script>