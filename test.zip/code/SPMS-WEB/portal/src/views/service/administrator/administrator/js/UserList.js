import UserInfo from '@/views/service/administrator/administrator/dialog/UserInfo';
import RoleRelation from '@/views/service/administrator/administrator/dialog/RoleRelation';
import Pagination from '@/customize/js/pagination';
import * as userService from '@/axios/userService';
import * as paramsService from '@/axios/paramsService';

export default {
  mixins: [Pagination],
  data() {
    return {
    	formLabelWidth:"100px",
    	info:{},
    	data:{},
    	initPwd:'888888',
    	isAdd:true,
    	roleRelation:{},
    	config:{},
    	roleVisible:false,
    	visible:false,
    	loading:false,
    	columns:[
					{label:'com.isoftchina.hes.common.user.name',prop:'name',width:'150px',visible:true},
					{label:'com.isoftchina.hes.common.user.account',prop:'loginname',width:'150px',visible:true},
					{label:'com.isoftchina.hes.common.user.iphone',prop:'phone',width:'120px',visible:true},
					{label:'static.SEX',prop:'sex',width:'60px',visible:true},
					{label:'com.isoftchina.hes.common.user.email',prop:'email',width:'150px',visible:true},
					{label:'com.isoftchina.hes.common.user.status',prop:'status',width:'120px',visible:true},
					{label:'com.isoftchina.hes.dept.name',prop:'deptId',width:'120px',visible:true}
				  ],
		dataList:[]
    }
  },
  methods:{
	  formatter(row, column,value){
	      	if(column.property=='sex') { return this.$t('static.sex_'  + value);}
			  else if(column.property=='status') { return this.$t('static.status_'  + value); }
			  else if(column.property=='deptId') { 
				if(row.deptId){
					for(var i=0;i<this.config.deptMenu.length;i++){
						if(row.deptId==this.config.deptMenu[i].id){
							return this.config.deptMenu[i].name;
						}
					}
				}
			}
	      	return value;
      },
	  getDataList(){
		  this.loading=true;
		  let param = Object.assign({params:this.data},this.page);
		  userService.getUserList(param).then(res=>{
			  this.loading=false;
			  if(res.success)
			  {
				  this.dataList= res.obj.results;
				  this.total=res.obj.totalRecord;
				  return;
			  }  
			  this.$message.error(this.$i18n.t('com.isoftchina.hes.common.error'));
		  });
	  },
	  reset(){
		  this.data={};
	  },
	  openRoleSet(info){
  		this.roleRelation=Object.assign({}, info);
  		this.roleVisible=true;
  	},
	 operationInfo(row){
			this.info = row ? Object.assign({}, row) : {password:this.initPwd,status:'0',sex:'0'};
			this.isAdd=!row;
			this.config.isAdd=this.isAdd;
			this.config.password=this.initPwd;
			!row || this.$set(this.info,"sex",String(this.info.sex));
            !row || this.$set(this.info,"status",String(this.info.status));
			this.visible=true;
	},
	submitRoleRelation(){
		this.roleRelation.roleIds=this.roleRelation.roleIds.join(",");
  		userService.grantUserInfo(this.roleRelation).then(res=>{
  			this.$message({ showClose: true, message: (res.success ? this.$t('com.isoftchina.hes.common.success') : this.$t('com.isoftchina.hes.common.fail')), type: (res.success ? 'success' : 'error') });
  			this.getDataList();
  			this.roleVisible=false;
  		});
     },
	  submitInfo(){
			userService[(this.isAdd ? 'add' : 'modify') + 'UserInfo'](this.info).then(res=>{
				this.$message({ showClose: true, message: (res.success ? this.$t('com.isoftchina.hes.common.success') : this.$t('com.isoftchina.hes.common.fail')), type: (res.success ? 'success' : 'error') });
				this.getDataList();
				this.visible=false;
			});
		},
		remove(){
  	        // 如果不是单选删除并且选中行数为0，则提示用户
  	        if(!this.sels.length) { this.$alert(this.$t('com.isoftchina.hes.common.delete.tip'),this.$t('com.isoftchina.hes.layout.header.tip'),{type:'warning'}); return; }
  	        this.$confirm(this.$t('com.isoftchina.hes.common.delete.comfirm'), this.$t('com.isoftchina.hes.layout.header.tip'), {type: 'warning'}).then(() => {
  		    	// 删除操作
  		    	userService.deleteUserInfo({id:this.sels.join(",")}).then(res=>{
  		    		this.$message({ showClose: true, message: (res.success ? this.$t('com.isoftchina.hes.common.success') : this.$t('com.isoftchina.hes.common.fail')), type: (res.success ? 'success' : 'error') });
					this.getDataList();
  	    		})
  		    }).catch(() => {});
    	}
  },
  components: {
	  UserInfo,
	  RoleRelation
   },
   mounted() {
	   this.getDataList();
	   // 性别
	   paramsService.getDictDataByType("sex").then(res=>{
		   this.$set(this.config,'sexMenu',res.obj);
	   })
	   // 状态
	   paramsService.getDictDataByType("status").then(res=>{
		   this.$set(this.config,'statusMenu',res.obj);
	   })

	   // 所有部门
	   userService.getDeptAll().then(res=>{
		this.$set(this.config,'deptMenu',res.obj);
	})
   }
};