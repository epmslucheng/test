<template>
	<section>
			<el-form size="mini" class="vue-form" :model="data" v-loading="loading">
				<div style="padding:10px;text-align:center;font-weight: bolder;border-bottom:1px dashed #ccc;">
					{{$t('com.isoftchina.hes.common.role.distributionmenu',[data.name])}}
				</div>
			    <div style="margin: 10px 0;"></div>
				<el-checkbox style="margin-left:24px" :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">{{$t('com.isoftchina.hes.common.selectall')}}</el-checkbox>
			    <div style="margin: 10px 0;"></div>
			    <el-scrollbar class="region_scrollbar" style="height:400px;">
				    <el-tree :data="menuList" show-checkbox node-key="id" ref="tree" :props="treeProps"
				    			 @check="handleNodeClick" :check-strictly="true" :default-expanded-keys="defaultExpandedKeys">
				    	<span slot-scope="{ node, data }">
				    		<span>{{$t(node.label)}}</span>
				    	</span>
				    </el-tree>
			    </el-scrollbar>
			</el-form>
	</section>
</template>
<script>
  import * as systemService from '@/axios/systemService';
  export default {
    props:['data'],
  	data() {
      return {
      	treeList:[],
      	menuList:[],
      	loading:true,
      	isIndeterminate:false,
      	defaultExpandedKeys:[],
      	checkAll:false,
      	treeProps: {
            label: 'name',
            children:'children'
        }
      }
    },
    methods: {
    	handleCheckAllChange(val){
    		this.data.resourceIds=val ? this.treeList.map(menu=>menu.id) : [];
    		this.$refs.tree.setCheckedKeys(this.data.resourceIds);
    		this.isIndeterminate=false;
    	},
    	handleNodeClick(data,node){
    		// 获取当前节点下所有子节点
    		let childrenMenusIds=this.getAllChildrenMenuIds(data,[]);
    		let checks=node.checkedKeys;
    		// 点击节点，取消或选中旗下的所有子集
    		this.data.resourceIds=checks.indexOf(data.id)>-1 ? Array.from(new Set(checks.concat(childrenMenusIds))) : checks.filter(menuId=>childrenMenusIds.indexOf(menuId)<0);
    		// 获取当前节点的所有父节点
    		let parentMenusIds=this.getAllParentMenuIds(this.treeList,data.pid,[]);
    		parentMenusIds.forEach(parentId=>{
    			this.data.resourceIds.indexOf(parentId)<0 && this.data.resourceIds.push(parentId);
    		})
    		
    		this.$refs.tree.setCheckedKeys(this.data.resourceIds);
    		let checkedCount = this.$refs.tree.getCheckedKeys().length;
        	this.checkAll = checkedCount === this.treeList.length;
        	this.isIndeterminate = checkedCount > 0 && checkedCount < this.treeList.length;
    	},
    	getAllChildrenMenuIds(data,arr){
    		if(data.children && data.children.length)
    		{
    			data.children.forEach(node=>{
    				arr.push(node.id);
    				this.getAllChildrenMenuIds(node,arr);
    			});
    		}
		    return arr;
    	},
    	getAllParentMenuIds(list,parentId,arr){
    		if(parentId==0)return arr;
    		list.forEach(node=>{
    			if(parentId==node.id)
    			{
    				arr.push(parentId);
    				this.getAllParentMenuIds(list,node.pid,arr);
    			}
    		})
    		return arr;
    	}
    },
    mounted(){
    	this.$set(this.data,'resourceIds',(this.data.resourceIds ? this.data.resourceIds.split(',') : []).map(Number));
		systemService.menuAxios().then(res=>{
			this.loading=false;
			//let usermanager=[2,2019030401,2019030402];// 屏蔽菜单【'管理员','用户管理','角色管理'】
			this.treeList=res.obj.filter(d=>d.name);
			let tree=this.$utils.listToTree("id","pid",this.treeList);
			tree.forEach(n=>{
				if(n.isLeaf) delete n.children;
				this.menuList.push(n);
			});
			this.checkAll=this.data.resourceIds.length==this.treeList.length;
			this.isIndeterminate=this.data.resourceIds.length > 0 && this.data.resourceIds.length < this.treeList.length;
			this.$nextTick(()=>{// 需延迟设置
				this.$refs.tree.setCheckedKeys(this.data.resourceIds);
				this.defaultExpandedKeys=this.data.resourceIds;// 默认展开勾选的菜单
			})
		});
    }
  };
</script>