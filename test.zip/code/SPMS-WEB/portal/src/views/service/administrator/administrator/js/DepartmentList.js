import DepartmentInfo from '@/views/service/administrator/administrator/dialog/DepartmentInfo';
import Pagination from '@/customize/js/pagination';
import * as userService from '@/axios/userService';
import * as paramsService from '@/axios/paramsService';

export default {
  mixins: [Pagination],
  data() {
    return {
    	formLabelWidth:"100px",
    	info:{},
    	data:{},
    	menuVisible:false,
    	visible:false,
    	isAdd:false,
    	config:{},
    	loading:false,
    	columns:[
					{label:'com.isoftchina.hes.dept.name',prop:'name',width:'120px',visible:true},
					{label:'com.isoftchina.hes.dept.code',prop:'code',width:'120px',visible:true},
					{label:'com.isoftchina.hes.common.description',prop:'description',width:'200px',visible:true}
				],
		dataList:[]
    }
  },
  methods:{
	  getDataList(){
		  this.loading=true;
		  let param = Object.assign({params:this.data},this.page);
		  userService.getDeptList(param).then(res=>{
			  this.loading=false;
			  if(res.success)
			  {
				  this.dataList= res.obj.results;
				  this.total=res.obj.totalRecord;
				  return;
			  }  
			  this.$message.error(this.$i18n.t('com.isoftchina.hes.common.error'));
		  });
	  },
	  reset(){
		  this.data={};
	  },
	  openMenuSet(info){
  		this.menuVisible=true;
  	},
   operationInfo(row){
	  this.info = row ? Object.assign({}, row) : {};
		this.isAdd=!row;
		this.config.isAdd=this.isAdd;
		!row || this.$set(this.info);
		this.visible=true;
	 },
	  submitInfo(){
			userService[(this.isAdd ? 'add' : 'modify') + 'DepartmentInfo'](this.info).then(res=>{
				this.$message({ showClose: true, message: (res.success ? this.$t('com.isoftchina.hes.common.success') : this.$t('com.isoftchina.hes.common.fail')), type: (res.success ? 'success' : 'error') });
				this.getDataList();
				this.visible=false;
			});
		},
	  remove(){
	        // 如果不是单选删除并且选中行数为0，则提示用户
	        if(!this.sels.length) { this.$alert(this.$t('com.isoftchina.hes.common.delete.tip'),this.$t('com.isoftchina.hes.layout.header.tip'),{type:'warning'}); return; }
	        let that=this;
	        this.$confirm(this.$t('com.isoftchina.hes.common.delete.comfirm'), this.$t('com.isoftchina.hes.layout.header.tip'), {type: 'warning'}).then(() => {
		    	// 删除操作
		    	userService.deleteDepartmentInfo(that.sels).then(res=>{
		    		this.$message({ showClose: true, message: (res.success ? this.$t('com.isoftchina.hes.common.success') : this.$t('com.isoftchina.hes.common.fail')), type: (res.success ? 'success' : 'error') });
					this.getDataList();
	    		})
		    }).catch(() => {});
  	}
  },
  components: {
	DepartmentInfo
   },
   mounted() {
	   this.getDataList();
	//    // 状态
	//    paramsService.getDictDataByType("status").then(res=>{
	// 	   this.$set(this.config,'statusMenu',res.obj);
	//    })
   }
};