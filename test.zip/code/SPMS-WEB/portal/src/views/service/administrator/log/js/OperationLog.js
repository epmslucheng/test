import * as paramsService from '@/axios/paramsService';
import * as logService from '@/axios/logService';
import Pagination from '@/customize/js/pagination';
export default {
	  mixins: [Pagination],
	  data() {
		    return {
		    	formLabelWidth:"120px",
		    	info:{},
		    	data:{},
		    	loading:false,
		    	columns:[
		    	         	{label:'static.LOGTYPE',prop:'logType',width:'100px',visible:true},
							{label:'com.isoftchina.hes.common.log.operationaccout',prop:'loginName',width:'120px',visible:true},
							{label:'com.isoftchina.hes.common.log.operationname',prop:'loginName',width:'120px',visible:true},
							{label:'com.isoftchina.hes.common.params.moudle',prop:'module',width:'120px',visible:true},
							{label:'com.isoftchina.hes.common.operation',prop:'optContent',width:'120px',visible:true},
							{label:'com.isoftchina.hes.common.log.createtime',prop:'createTime',width:'120px',visible:true},
							{label:'com.isoftchina.hes.common.log.operationdetail',prop:'optDetail',width:'200px',visible:true}
						],
				dataList:[],
				logOperTypeList:[],
				logModuleList:[]
		    }
		  },
		  computed: {
			  filterLogModule(){return this.logModuleList.filter(item=>this.data.modules.indexOf(item.value) > -1).map(item=>this.$t('static.'+item.codeType+'_'+ item.value)).join(",")},
			  pickerOptions(){return {shortcuts: this.$utils.shortcuts()}}
		  },
		  methods:{
			  formatter(row, column,value){
				    if(column.property=='logType') { return this.$t('static.logType_'  + value);}
			      	if(column.property=='module') { return this.$t('static.system_'  + value);}
			      	if(column.property=='createTime') { return this.$utils.formatDate.format(new Date(value),"yyyy-MM-dd hh:mm:ss");}
			      	return value;
		      },
			  getDataList(){
				  this.loading=true;
				  let param = Object.assign({params:this.data},this.page);
				  logService.queryPageSysLog(param).then(res=>{
					  this.loading=false;
					  if(res.success)
					  {
						  this.dataList= res.obj.results;
						  this.total=res.obj.totalRecord;
						  return;
					  }  
					  this.$message.error(this.$i18n.t('com.isoftchina.hes.common.error'));
				  });
			  },
			  reset(){
				  this.data={modules:[]};
			  }
		  },
		  mounted() {
			  this.getDataList();
			  paramsService.getDictDataByType("system").then(res=>{ this.logModuleList=res.obj; });
			  paramsService.getDictDataByType("logType").then(res=>{ this.logOperTypeList=res.obj; });
		   }
};