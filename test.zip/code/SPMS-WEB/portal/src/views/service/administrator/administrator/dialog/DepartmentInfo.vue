<template>
	<section>
		<el-form class="vue-form" :model="data" :rules="rules" size="mini">
			  	<el-row>
			  		<el-col :span="12">
			  			<el-form-item :label="$t('com.isoftchina.hes.dept.name')" :label-width="formLabelWidth" prop="name">
					      <el-input v-model="data.name" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + $t('com.isoftchina.hes.dept.name')" clearable></el-input>
					    </el-form-item>
			  		</el-col>
						<el-col :span="12">
			  			<el-form-item :label="$t('com.isoftchina.hes.dept.code')" :label-width="formLabelWidth" prop="name">
					      <el-input v-model="data.code" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + $t('com.isoftchina.hes.dept.code')" clearable></el-input>
					    </el-form-item>
			  		</el-col>
			  	</el-row>	
			  	<el-row>	
			  		<el-col :span="24">
			  			<el-form-item :label="$t('com.isoftchina.hes.common.description')" :label-width="formLabelWidth" prop="description">
					      <el-input type="textarea" v-model="data.description"></el-input>
					    </el-form-item>
			  		</el-col>
			  	</el-row>
		</el-form>
	</section>
</template>
<script>
  export default {
    props:['data','config'],
  	data() {
      return {
			      	formLabelWidth:'110px',
			      	rules:{
			      		name:[
			      					{required: true, message: (this.$t('com.isoftchina.hes.dept.name') + this.$t('com.isoftchina.hes.common.notnull')),  trigger: 'blur'}
			      				],
								code:[
			      					{required: true, message: (this.$t('com.isoftchina.hes.dept.code') + this.$t('com.isoftchina.hes.common.notnull')),  trigger: 'blur'}
			      				]
			      	}
     			 }
    }
  };
</script>