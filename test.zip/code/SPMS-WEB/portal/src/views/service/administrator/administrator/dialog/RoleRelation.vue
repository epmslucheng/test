<template>
	<section>
			<el-form size="mini" class="vue-form" :model="data" v-loading="loading">
				<div style="padding:10px;text-align:center;font-weight: bolder;border-bottom:1px dashed #ccc;">
					{{$t('com.isoftchina.hes.common.user.distributionrole',[data.name])}}
				</div>
			    <div style="margin: 10px 0;"></div>
				<el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">{{$t('com.isoftchina.hes.common.selectall')}}</el-checkbox>
			    <div style="margin: 10px 0;"></div>
			    <el-scrollbar class="region_scrollbar"  style="height:400px;">
			    <el-checkbox-group v-model="data.roleIds" @change="handleCheckedChange">
			    	<el-row :span="24" v-for="(role,index) in roleList" :key="index" style="padding:5px 0;">
			         	<el-checkbox :label="String(role.id)">{{role.name}}</el-checkbox>
			    	</el-row>
			    </el-checkbox-group>
			    </el-scrollbar>
			</el-form>
	</section>
</template>
<script>
  import * as userService from '@/axios/userService';
  export default {
    props:['data'],
  	data() {
      return {
      	roleList:[],
      	loading:false,
      	checkAll:false,
      	isIndeterminate:false
      }
    },
    methods: {
      handleCheckAllChange(val) {
        this.data.roleIds=val ? this.roleList.map(role=>String(role.id)) : [];
        this.isIndeterminate = false;
      },
      handleCheckedChange(value) {
        let checkedCount = value.length;
        this.checkAll = checkedCount === this.roleList.length;
        this.isIndeterminate = checkedCount > 0 && checkedCount < this.roleList.length;
      }
    },
    mounted(){
       // 查询所有角色
       this.$set(this.data,'roleIds',this.data.roleIds ? this.data.roleIds.split(',') : []);
       this.loading=true;
       userService.getAllRoleList().then(res=>{
	       this.loading=false;
	       this.roleList=res.obj;
	       this.checkAll=this.data.roleIds.length==this.roleList.length;
	       this.isIndeterminate=this.data.roleIds.length > 0 && this.data.roleIds.length < this.roleList.length;
       });
    }
  };
</script>