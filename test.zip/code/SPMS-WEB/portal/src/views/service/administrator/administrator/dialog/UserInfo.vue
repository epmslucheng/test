<template>
	<section>
		<el-form class="vue-form" :model="data" :rules="rules" size="mini">
			  	<el-row>
			  		<el-col :span="12">
			  			<el-form-item :label="$t('com.isoftchina.hes.common.user.name')" :label-width="formLabelWidth" prop="name">
					      <el-input :disabled="config.filterable" v-model="data.name" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + $t('com.isoftchina.hes.common.user.name')" clearable></el-input>
					    </el-form-item>
			  		</el-col>
			  		<el-col :span="12">
			  			<el-form-item :label="$t('com.isoftchina.hes.common.user.account')" :label-width="formLabelWidth" prop="loginname">
					      <el-input :disabled="!config.isAdd || config.filterable" v-model="data.loginname" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + $t('com.isoftchina.hes.common.user.account')" clearable></el-input>
					    </el-form-item>
			  		</el-col>
			  	</el-row>	
			  	<el-row>
			  		<el-col :span="12">
			  			<el-form-item :label="$t('static.SEX')" :label-width="formLabelWidth" prop="sex">
					      <el-select :disabled="config.filterable" v-model="data.sex" :placeholder="$t('com.isoftchina.hes.common.pleaseSelect')">
						    <el-option v-for="item in config.sexMenu" :key="item.value" :label="$t('static.'+item.codeType+'_'+item.value)" :value="item.value"></el-option>
						  </el-select>
					    </el-form-item>
			  		</el-col>
			  		<el-col :span="12">
			  			<el-form-item :label="$t('com.isoftchina.hes.common.user.status')" :label-width="formLabelWidth" prop="status">
					      <el-select :disabled="config.filterable" v-model="data.status" :placeholder="$t('com.isoftchina.hes.common.pleaseSelect')">
							    <el-option v-for="item in config.statusMenu" :key="item.value" :label="$t('static.'+item.codeType+'_'+item.value)" :value="item.value"></el-option>
							  </el-select>
					    </el-form-item>
			  		</el-col>
			  	</el-row>	
			  	<el-row>
			  		<el-col :span="12">
			  			<el-form-item :label="$t('com.isoftchina.hes.common.user.iphone')" :label-width="formLabelWidth" prop="phone">
					      <el-input v-model="data.phone" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + $t('com.isoftchina.hes.common.user.iphone')" clearable></el-input>
					    </el-form-item>
			  		</el-col>
			  		<el-col :span="12">
			  			<el-form-item :label="$t('com.isoftchina.hes.common.user.email')" :label-width="formLabelWidth" prop="email">
					      <el-input v-model="data.email" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + $t('com.isoftchina.hes.common.user.email')" clearable></el-input>
					    </el-form-item>
			  		</el-col>
			  	</el-row>
			  	<el-row>	
						<el-col :span="12">
			  			<el-form-item :label="$t('com.isoftchina.hes.dept.name')" :label-width="formLabelWidth" prop="status">
					      <el-select :disabled="config.filterable" v-model="data.deptId" :placeholder="$t('com.isoftchina.hes.common.pleaseSelect')">
							    <el-option v-for="item in config.deptMenu" :key="item.id" :label="item.name" :value="item.id"></el-option>
							  </el-select>
					    </el-form-item>
							</el-col>
			  	</el-row>
					<el-row v-if="!config.filterable">
			  		<el-col :span="12">
			  			<el-form-item :label="$t('com.isoftchina.hes.common.user.password')" :label-width="formLabelWidth" prop="password">
					      <el-input :disabled="true" v-model="data.password" autocomplete="new-password" :placeholder="$t('com.isoftchina.hes.common.user.initpwd') + ':' +config.password" clearable></el-input>
					    </el-form-item>
			  		</el-col>
		  			<el-col :span="6" class="ml12"  v-if="!config.isAdd">
		  					<el-form-item><el-button size="mini" @click.native.stop="resetPwd"><span style="padding:0 5px;">{{$t('com.isoftchina.hes.common.user.resetpwd')}}</span></el-button></el-form-item>
		  			</el-col>
			  	</el-row>
		</el-form>
	</section>
</template>
<script>
  export default {
    props:['data','config'],
  	data() {
      return {
			      	formLabelWidth:'110px',
			      	rules:{
			      		loginname:[
			      					{required: true, message: (this.$t('com.isoftchina.hes.common.user.account') + this.$t('com.isoftchina.hes.common.notnull')),  trigger: 'blur'}
			      				],
			      		phone:[
			      					{validator: this.$validate.checkPhoneNumber ,message: this.$t('com.isoftchina.hes.common.phone'),trigger: 'blur'}
			      				],
			      		email:[
			      					{validator: this.$validate.checkEmail ,message: this.$t('com.isoftchina.hes.common.email'),trigger: 'blur'}
			      				],
			      	}
     			 }
    },
    methods: {
    	resetPwd(){
    		this.$set(this.data,"password",this.config.password);
    	}
    }
  };
</script>