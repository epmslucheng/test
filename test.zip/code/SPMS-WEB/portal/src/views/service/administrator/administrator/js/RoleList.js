import RoleInfo from '@/views/service/administrator/administrator/dialog/RoleInfo';
import MenuRelation from '@/views/service/administrator/administrator/dialog/MenuRelation';
import Pagination from '@/customize/js/pagination';
import * as userService from '@/axios/userService';
import * as paramsService from '@/axios/paramsService';

export default {
  mixins: [Pagination],
  data() {
    return {
    	formLabelWidth:"100px",
    	info:{},
    	data:{},
    	menuVisible:false,
    	visible:false,
    	menuRelation:{},
    	isAdd:false,
    	config:{},
    	loading:false,
    	columns:[
    	         	{label:'com.isoftchina.hes.common.role.seq',prop:'seq',width:'80px',visible:true},
					{label:'com.isoftchina.hes.common.role.name',prop:'name',width:'120px',visible:true},
					{label:'com.isoftchina.hes.common.role.stauts',prop:'status',width:'120px',visible:true},
					{label:'com.isoftchina.hes.common.description',prop:'description',width:'200px',visible:true}
				],
		dataList:[]
    }
  },
  methods:{
	  formatter(row, column,value){
	      	if(column.property=='status') { return this.$t('static.status_'  + value); }
	      	return value;
     },
	  getDataList(){
		  this.loading=true;
		  let param = Object.assign({params:this.data},this.page);
		  userService.getRoleList(param).then(res=>{
			  this.loading=false;
			  if(res.success)
			  {
				  this.dataList= res.obj.results;
				  this.total=res.obj.totalRecord;
				  return;
			  }  
			  this.$message.error(this.$i18n.t('com.isoftchina.hes.common.error'));
		  });
	  },
	  reset(){
		  this.data={};
	  },
	  openMenuSet(info){
  		this.menuRelation=Object.assign({}, info);
  		this.menuVisible=true;
  	},
  	submitMenuRelation(){
  		this.menuRelation.resourceIds=this.menuRelation.resourceIds.join(",");
  		userService.grantRoleInfo(this.menuRelation).then(res=>{
  			this.$message({ showClose: true, message: (res.success ? this.$t('com.isoftchina.hes.common.success') : this.$t('com.isoftchina.hes.common.fail')), type: (res.success ? 'success' : 'error') });
  			this.getDataList();
  			this.menuVisible=false;
  		});
    },
   operationInfo(row){
	  this.info = row ? Object.assign({}, row) : {status:'0'};
		this.isAdd=!row;
		this.config.isAdd=this.isAdd;
		!row || this.$set(this.info,"status",String(this.info.status));
		this.visible=true;
	 },
	  submitInfo(){
			userService[(this.isAdd ? 'add' : 'modify') + 'RoleInfo'](this.info).then(res=>{
				this.$message({ showClose: true, message: (res.success ? this.$t('com.isoftchina.hes.common.success') : this.$t('com.isoftchina.hes.common.fail')), type: (res.success ? 'success' : 'error') });
				this.getDataList();
				this.visible=false;
			});
		},
	  remove(){
	        // 如果不是单选删除并且选中行数为0，则提示用户
	        if(!this.sels.length) { this.$alert(this.$t('com.isoftchina.hes.common.delete.tip'),this.$t('com.isoftchina.hes.layout.header.tip'),{type:'warning'}); return; }
	        let that=this;
	        this.$confirm(this.$t('com.isoftchina.hes.common.delete.comfirm'), this.$t('com.isoftchina.hes.layout.header.tip'), {type: 'warning'}).then(() => {
		    	// 删除操作
		    	userService.deleteRoleInfo(that.sels).then(res=>{
		    		this.$message({ showClose: true, message: (res.success ? this.$t('com.isoftchina.hes.common.success') : this.$t('com.isoftchina.hes.common.fail')), type: (res.success ? 'success' : 'error') });
					this.getDataList();
	    		})
		    }).catch(() => {});
  	}
  },
  components: {
	  RoleInfo,
	  MenuRelation
   },
   mounted() {
	   this.getDataList();
	   // 状态
	   paramsService.getDictDataByType("status").then(res=>{
		   this.$set(this.config,'statusMenu',res.obj);
	   })
   }
};