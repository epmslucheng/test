<template>
	<el-container class="page-container">
		  <el-header height="230px">
			<el-form class="vue-form mt10" :model="data" size="mini">
			<el-row>
				<el-col :span="24">
					<fieldset class="log-tip--wrap">
					    <legend>{{$t('com.isoftchina.hes.common.log.filteroptions')}}:</legend>
					  	<el-tag v-if="data.modules && data.modules.length" size="mini" disable-transitions class="filter-item">{{filterLogModule}}</el-tag>
				  </fieldset>
				</el-col>
			</el-row>
			<el-row class="mt20">
				<el-col :span="24">
					<el-row>
						<el-col :span="7">
				  			<el-form-item :label="$t('static.LOGTYPE')" :label-width="formLabelWidth">
						      <el-select v-model="data.logType" :placeholder="$t('com.isoftchina.hes.common.pleaseSelect')" clearable>
								   <el-option v-for="item in logOperTypeList" :key="item.value" :label="$t('static.'+item.codeType+'_'+ item.value)" :value="item.value"></el-option>
							   </el-select>
						    </el-form-item>
				  		</el-col>
				  		<el-col :span="7">
				  			<el-form-item :label="$t('com.isoftchina.hes.common.params.moudle')" :label-width="formLabelWidth" class="multiple-select">
						      <el-select v-model="data.modules" collapse-tags multiple :placeholder="$t('com.isoftchina.hes.common.pleaseSelect')" clearable>
								   <el-option v-for="item in logModuleList" :key="item.name" :label="$t('static.'+item.codeType+'_'+ item.value)" :value="item.value"></el-option>
							   </el-select>
						    </el-form-item>
				  		</el-col>
				  	</el-row>
				  	<el-row>
				  		<el-col :span="7">
				  			<el-form-item :label="$t('com.isoftchina.hes.common.log.operationaccout')" :label-width="formLabelWidth">
						      <el-input size="mini" v-model="data.loginName" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + $t('com.isoftchina.hes.common.log.operationaccout')" clearable></el-input>
						    </el-form-item>
				  		</el-col>
				  		<el-col :span="7">
				  			<el-form-item :label="$t('com.isoftchina.hes.common.operation')" :label-width="formLabelWidth">
						      <el-input size="mini" v-model="data.optContent" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + $t('com.isoftchina.hes.common.operation')" clearable></el-input>
						    </el-form-item>
				  		</el-col>
				  	</el-row>
				  	<el-row>
				  		<el-col :span="10">
				  			<el-form-item :label="$t('com.isoftchina.hes.common.log.timeranges')" :label-width="formLabelWidth">
						      <el-date-picker value-format="yyyy-MM-dd HH:mm:ss" size="mini" popper-class="date-picker" v-model="data.rangeDate" type="datetimerange" align="left" unlink-panels :range-separator="$t('com.isoftchina.hes.common.to')"
												      :start-placeholder="$t('com.isoftchina.hes.common.startdate')" :end-placeholder="$t('com.isoftchina.hes.common.enddate')" :picker-options="pickerOptions" :editable="false" clearable>
							  </el-date-picker>
						    </el-form-item>
				  		</el-col>
				  		<el-col :span="4" class="tr">
				  			<el-button type="primary" icon="fa fa-search" size="mini" @click.native.stop="()=>getDataList()">{{$t('com.isoftchina.hes.common.query')}}</el-button>
				  			<el-button size="mini" icon="fa fa-eraser" @click.native.stop="()=>reset()">{{$t('com.isoftchina.hes.common.reset')}}</el-button>
				  		</el-col>
				  	</el-row>
				</el-col>
			</el-row>
		  </el-form>
		</el-header>
		<el-main>
			<div class="full-screen" v-loading="loading">
				<div style="position:absolute;">
		  			<el-button size="mini" icon="fa fa-download">{{$t('com.isoftchina.hes.common.export')}}</el-button>
		  		</div>
			    <el-grid :data="dataList" :columns="columns" :show-checkbox="false" :show-operation="false" :formatter="formatter"></el-grid>
			</div>
		</el-main>
		<el-footer height="40px">
			<el-pagination background :layout="layout" class="fr" 
									:total="total" 
	    							:page-sizes="pageSizes" 
	    							:page-size="page.pageSize" 
	    							:current-page="page.pageNo" 
									@size-change="sizeChange"
									@current-change="currentChange"></el-pagination>
		</el-footer>
	</el-container>
</template>
<script src="./js/OperationLog.js"></script>