import DictionariesInfo from '@/views/service/administrator/system/dialog/DictionariesInfo';
import * as paramsService from '@/axios/paramsService';
import Pagination from '@/customize/js/pagination';
export default {
	  mixins: [Pagination],
	  data() {
		    return {
		    	formLabelWidth:"120px",
		    	info:{},
		    	data:{},
		    	visible:false,
		    	loading:false,
		    	columns:[
							{label:'com.isoftchina.hes.common.dictionaries.name',prop:'name',width:'150px',visible:true},
							{label:'com.isoftchina.hes.common.dictionaries.classification',prop:'codeType',width:'150px',visible:true},
							{label:'com.isoftchina.hes.common.dictionaries.maintenancetype',prop:'maintainType',width:'150px',visible:true}
						],
				dataList:[],
				dataAllList:[]
		    }
		  },
		  methods:{
			  formatter(row, column,value){
				    if(column.property=='name') { return this.$t('static.'  + value);}
			      	if(column.property=='maintainType') { return this.$t('com.isoftchina.hes.common.dictionaries.maintenancetype_'  + value);}
			      	return value;
		      },
			  getDataList(){
				  this.loading=true;
				  let param = Object.assign({params:this.data},this.page);
				  paramsService.getDictionariesList(param).then(res=>{
					  this.loading=false;
					  if(res.success)
					  {
						  this.dataList= res.obj.results;
						  this.total=res.obj.totalRecord;
						  return;
					  }  
					  this.$message.error(this.$i18n.t('com.isoftchina.hes.common.error'));
				  });
			  },
			  operationInfo(row){
					this.info = row ? Object.assign({}, row) : {};
					this.visible=true;
				},
				submitInfo(){
					
				},
				reset(){
					  this.data={};
				  },
		  },
		  components: {
			  DictionariesInfo
		   },
		  mounted() {
			   this.getDataList();
			   paramsService.getAllDictionariesList().then(res=>{ if(res.success)this.dataAllList=res.obj; });
		   }
};