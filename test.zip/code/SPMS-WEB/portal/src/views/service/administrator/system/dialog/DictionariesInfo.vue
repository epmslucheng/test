<template>
	<section>
		<el-container class="page-container">
			<el-main v-loading="loading">
				<div style="position:absolute;">
					<el-button v-if="data.maintainType==0 || data.maintainType==3" size="mini"  icon="fa fa-plus" @click.native="createModify()" type="primary">{{$t('com.isoftchina.hes.common.add')}}</el-button>
				</div>
				<el-grid :data="dataList" :columns="columns" :show-checkbox="false"  :show-operation="false"  :formatter="formatter" :show-row-number="false">
					<el-table-column :label="$t('com.isoftchina.hes.common.operation')" width="120" fixed align="center" v-if="data.maintainType!=4">
					      <template slot-scope="{row,$index}">
					      		<el-tag v-if="data.maintainType==0 || data.maintainType==1" size="mini" :disable-transitions="true" class="vue-tag" @click.native="()=>createModify(row)">{{$t('com.isoftchina.hes.common.modify')}}</el-tag>
					        	<el-tag v-if="data.maintainType==0 || data.maintainType==2" size="mini" :disable-transitions="true" class="vue-tag" @click.native="()=>remove(row)">{{$t('com.isoftchina.hes.common.del')}}</el-tag>
					      </template>
				    </el-table-column>
				</el-grid>
			</el-main>
			<el-footer height="80px">
				<el-row>
					<el-pagination background :layout="layout" class="fr" 
									:total="total" 
	    							:page-sizes="pageSizes" 
	    							:page-size="page.pageSize" 
	    							:current-page="page.pageNo" 
									@size-change="sizeChange"
									@current-change="currentChange"></el-pagination>
				</el-row>
				<el-row class="mt20">
					<el-button class="fr" @click.native.stop="cancelModel" size="small">{{$t('com.isoftchina.hes.common.cancel')}}</el-button>
				</el-row>
			</el-footer>
		</el-container>
		<el-dialog :title="isAdd ? $t('com.isoftchina.hes.common.add') : $t('com.isoftchina.hes.common.modify')" :visible.sync="innerVisible" width="700px" append-to-body :close-on-click-modal="false" v-loading="innerLoading">
	  	 <el-form class="vue-form mt10 ml10" :model="data" size="mini" bg :inline="true">
	  	 	<el-form-item :label="$t('com.isoftchina.hes.common.dictionaries.name')" :label-width="formLabelWidth">
		    	<el-input :value="getName" autocomplete="off" disabled></el-input>
		    </el-form-item>
		    <el-form-item :label="$t('com.isoftchina.hes.common.dictionaries.classification')" :label-width="formLabelWidth">
		    	<el-input v-model="data.codeType" autocomplete="off" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + $t('com.isoftchina.hes.common.dictionaries.classification')" disabled></el-input>
		    </el-form-item>
			<el-form-item :label="$t('com.isoftchina.hes.common.no')" :label-width="formLabelWidth">
		    	<el-input-number class="tl" v-model="row.dispSn" size="mini" controls-position="right" style="width:178px;text-align:left;" :min="1"></el-input-number>	
		    </el-form-item>
		    <el-form-item :label="$t('com.isoftchina.hes.common.dictionaries.codevalue')" :label-width="formLabelWidth">
		    	<el-input v-model="row.value" autocomplete="off" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + $t('com.isoftchina.hes.common.dictionaries.codevalue')"></el-input>
		    </el-form-item>
		    <el-form-item :label="$t('static.VALID_FLAG')" :label-width="formLabelWidth">
		    	 <el-select v-model="row.validFlag" :placeholder="$t('com.isoftchina.hes.common.pleaseSelect')" style="width:178px;">
				    <el-option v-for="item in effectiveMenu" :key="item.name" :label="$t('static.'+item.codeType+'_'+ item.value)" :value="item.value"> </el-option>
				  </el-select>
		    </el-form-item>
		  </el-form>
		  <span class="ml10 red">{{$t('static.notes')}}</span>
		  <span slot="footer" class="dialog-footer layout">
		    <el-button size="small" @click="innerVisible = false">{{$t('com.isoftchina.hes.common.cancel')}}</el-button>
		    <el-button size="small"  type="primary" @click="submitInfo">{{$t('com.isoftchina.hes.common.ok')}}</el-button>
		  </span>
		</el-dialog>
	</section>
</template>
<script>
  import * as paramsService from '@/axios/paramsService';
  import Pagination from '@/customize/js/pagination';
  export default {
    mixins: [Pagination],
    props:['data'],
  	data() {
      return {
      	formLabelWidth:'130px',
        dataList:[],
        loading:false,
        innerLoading:false,
        innerVisible:false,
        effectiveMenu:[],
        row:{},
        isAdd:true,
      	columns:[
			{label:'com.isoftchina.hes.common.no',prop:'dispSn',width:'40px',visible:true,align:'center'},
      		{label:'com.isoftchina.hes.common.dictionaries.classification',prop:'codeType',width:'150px',visible:true},
      		{label:'com.isoftchina.hes.common.dictionaries.codevalue',prop:'value',width:'80px',visible:true},
			{label:'com.isoftchina.hes.common.dictionaries.classificationname',prop:'classificationName',width:'200px',visible:true},
			{label:'static.VALID_FLAG',prop:'validFlag',width:'80px',visible:true}
      	]
      }
    },
    methods:{
    	formatter(row, column,value){
			    if(column.property=='classificationName') {return this.$t('static.'  + row.codeType + '_'+row.value);}
			    if(column.property=='validFlag') {return this.$t('static.'  + column.property + '_'+value);}
		      	return value;
	      },
	    createModify(row){
	    	this.isAdd=!row;
	    	this.row = row ? Object.assign({}, row) : {typeId:this.data.id,validFlag:'0',codeType:this.data.codeType};
	    	this.innerVisible=true;
	    },  
	    remove(row){
	    	this.$confirm(this.$t('com.isoftchina.hes.common.delete.comfirm'), this.$t('com.isoftchina.hes.layout.header.tip'), {type: 'warning'}).then(() => {
  		    	// 删除操作
  		    	paramsService.delDictData([row.id]).then(res=>{
    				this.$message({ showClose: true, message: (res.success ? this.$t('com.isoftchina.hes.common.success') : this.$t('com.isoftchina.hes.common.fail')), type: (res.success ? 'success' : 'error') });
    				this.getDataList();
    			});
  		    }).catch(() => {});
	    },
	    submitInfo(){
	    	this.innerLoading=true;
	    	paramsService[(this.isAdd ? 'add' : 'modify') + 'DictData'](this.row).then(res=>{
	    		this.innerLoading=false;
    			this.$message({ showClose: true, message: (res.success ? this.$t('com.isoftchina.hes.common.success') : this.$t('com.isoftchina.hes.common.fail')), type: (res.success ? 'success' : 'error') });
    			this.getDataList();
    			this.innerVisible=false;
    		});
	    },
    	cancelModel(){
    		this.$emit("update:visible",false);
    	},
    	getDataList(){
    		// 查询分页分类枚举
    		this.loading=true;
    		let param = Object.assign({params:this.data},this.page);
    		paramsService.queryPageDictData(param).then(res=>{
    			this.loading=false;
    			this.dataList=res.obj.results;
    			this.total=res.obj.totalRecord;
    		});
    	}
    },
    computed:{
    	getName(){
    		if(this.row.value)return this.$t('static.'+this.data.codeType+'_'+this.row.value);
    		return "";
    	}
    },
    mounted() {
		this.getDataList();
		// 生效标识枚举
		paramsService.getDictDataByType("validFlag").then(res=>{ this.effectiveMenu=res.obj; });
	}
  };
</script>