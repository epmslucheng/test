<template>
	<section>
		<el-form :model="pwdForm" bg size="small" ref="pwdForm" label-position="left" label-width="140px" :rules="rules" class="mt10 vue-form">
			<span class="account-label"></span>
		    <el-form-item prop="oldPassword" :label="$t('com.isoftchina.hes.login.resetpassword.old')">
		      <el-input type="password" v-model="pwdForm.oldPassword" auto-complete="new-password" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter')+$t('com.isoftchina.hes.login.resetpassword.old')" clearable></el-input>
		    </el-form-item>
		    <el-form-item prop="password" :label="$t('com.isoftchina.hes.login.resetpassword.new')">
		      <el-input type="password" v-model="pwdForm.password" auto-complete="new-password" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter')+$t('com.isoftchina.hes.login.resetpassword.new')" clearable></el-input>
		    </el-form-item>
		    <el-form-item prop="confirmPassword" :label="$t('com.isoftchina.hes.login.resetpassword.confirm')">
		      <el-input type="password" v-model="pwdForm.confirmPassword" auto-complete="new-password" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter')+$t('com.isoftchina.hes.login.resetpassword.confirm')" clearable></el-input>
		    </el-form-item>
		 </el-form>
	</section>
</template>
<script>
  export default {
  	props:['pwdForm'],
    data() {
     let validateLoginName = (rule, value, callback) => {
	    	if(value==this.pwdForm.loginname) { callback(new Error(rule.message)); return;  }
			callback();
		};
      let validatePass = (rule, value, callback) => {
	    	if(value==this.pwdForm.oldPassword) { callback(new Error(rule.message)); return;  }
	    	if(this.pwdForm.confirmPassword) { this.$refs.pwdForm.validateField('confirmPassword'); }
			callback();
		};
	  let validatePass2 = (rule, value, callback) => { if (value != this.pwdForm.password) { callback(new Error(rule.message)); } else { callback(); } };
	  let user=JSON.parse(sessionStorage.getItem('user'));
      return {
      	disabled:false,
      	rules:{ 
	    	oldPassword:[ 
	    							{required: true, message: this.$t('com.isoftchina.hes.login.resetpassword.old') + this.$t('com.isoftchina.hes.common.notnull')}
	    						],
	    	password:[ 
	    							{required: true, message: this.$t('com.isoftchina.hes.login.resetpassword.new') + this.$t('com.isoftchina.hes.common.notnull')},
	    							{validator: validateLoginName, message: this.$t('com.isoftchina.hes.common.req1'),trigger: 'blur'},
	    							{validator: this.$validate.checkPassword, trigger: 'blur'},
	    							{validator: validatePass,message:this.$t('com.isoftchina.hes.common.req2'),trigger: 'blur'}
	    						],
	    	confirmPassword:[ 
	    							{required: true, message: this.$t('com.isoftchina.hes.login.resetpassword.confirm') + this.$t('com.isoftchina.hes.common.notnull')},
	    							{validator: validatePass2,message: this.$t('com.isoftchina.hes.common.req8'),trigger: 'blur'}
	    						]									
	    }
      };
    }
  }
</script>