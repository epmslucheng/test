import ParamInfo from '@/views/service/administrator/system/dialog/ParamInfo';
import * as paramsService from '@/axios/paramsService';
import Pagination from '@/customize/js/pagination';
export default {
	  mixins: [Pagination],
	  data() {
		    return {
		    	formLabelWidth:"110px",
		    	info:{},
		    	data:{},
		    	loading:false,
		    	visible:false,
		    	mouduleList:[],
		    	columns:[
							{label:'com.isoftchina.hes.common.params.moudle',prop:'module',width:'150px',visible:true},
							{label:'com.isoftchina.hes.common.params.name',prop:'name',width:'150px',visible:true},
							{label:'com.isoftchina.hes.common.params.value',prop:'value',width:'120px',visible:true},
							{label:'com.isoftchina.hes.common.description',prop:'remark',width:'200px',visible:true}
						],
				dataList:[]
		    }
		  },
		  methods:{
			  getDataList(){
				  this.loading=true;
				  let param = Object.assign({params:this.data},this.page);
				  paramsService.getSystemConfigList(param).then(res=>{
					  this.loading=false;
					  if(res.success)
					  {
						  this.dataList= res.obj.results;
						  this.total=res.obj.totalRecord;
						  return;
					  }  
					  this.$message.error(this.$i18n.t('com.isoftchina.hes.common.error'));
				  });
			  },
			  reset(){
				  this.data={};
			  },
			  operationInfo(row){
					this.info = row ? Object.assign({}, row) : {};
					this.visible=true;
				},
				submitInfo(){
					paramsService.modifySystemConfigInfo(this.info).then(res=>{
						this.$message({ showClose: true, message: (res.success ? this.$t('com.isoftchina.hes.common.success') : this.$t('com.isoftchina.hes.common.fail')), type: (res.success ? 'success' : 'error') });
						this.getDataList();
						this.visible=false;
					});
				}
		  },
		  components: {
			  ParamInfo
		   },
		  mounted() {
			   // 查询所有模块用于select下拉展示
			   paramsService.getAllSystemConfigList().then(res=>{
				  if(res.success) { this.mouduleList=res.obj; return; }  
				  this.$message.error(this.$i18n.t('com.isoftchina.hes.common.error'));
			   })
			   this.getDataList();
		   }
};