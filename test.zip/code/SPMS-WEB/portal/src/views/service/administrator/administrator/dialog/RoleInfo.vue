<template>
	<section>
		<el-form class="vue-form" :model="data" :rules="rules" size="mini">
			  	<el-row>
			  		<el-col :span="12">
			  			<el-form-item :label="$t('com.isoftchina.hes.common.role.name')" :label-width="formLabelWidth" prop="name">
					      <el-input v-model="data.name" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + $t('com.isoftchina.hes.common.role.name')" clearable></el-input>
					    </el-form-item>
			  		</el-col>
			  		<el-col :span="12">
			  			<el-form-item :label="$t('com.isoftchina.hes.common.role.stauts')" :label-width="formLabelWidth" prop="status">
					      <el-select v-model="data.status" :placeholder="$t('com.isoftchina.hes.common.pleaseSelect')">
							    <el-option v-for="item in config.statusMenu" :key="item.value" :label="$t('static.'+item.codeType+'_'+item.value)" :value="item.value"></el-option>
							  </el-select>
					    </el-form-item>
			  		</el-col>
			  	</el-row>	
			  	<el-row>
			  		<el-col :span="12">
			  			<el-form-item :label="$t('com.isoftchina.hes.common.role.seq')" :label-width="formLabelWidth" prop="seq">
					   	  <el-input-number class="tl" v-model="data.seq" size="mini" controls-position="right" style="width:100%;" :min="1"></el-input-number>
					    </el-form-item>
			  		</el-col>
			  	</el-row>	
			  	<el-row>	
			  		<el-col :span="24">
			  			<el-form-item :label="$t('com.isoftchina.hes.common.description')" :label-width="formLabelWidth" prop="description">
					      <el-input type="textarea" v-model="data.description"></el-input>
					    </el-form-item>
			  		</el-col>
			  	</el-row>
		</el-form>
	</section>
</template>
<script>
  export default {
    props:['data','config'],
  	data() {
      return {
			      	formLabelWidth:'110px',
			      	rules:{
			      		name:[
			      					{required: true, message: (this.$t('com.isoftchina.hes.common.role.name') + this.$t('com.isoftchina.hes.common.notnull')),  trigger: 'blur'}
			      				]
			      	}
     			 }
    }
  };
</script>