<template>
	<section>
		<el-form class="vue-form" :model="data" :rules="rules" size="mini">
			  	<el-row>
			  		<el-col :span="12">
			  			<el-form-item :label="$t('com.isoftchina.hes.common.params.name')" :label-width="formLabelWidth" prop="name">
					      <el-input disabled v-model="data.name" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + $t('com.isoftchina.hes.common.params.name')" clearable></el-input>
					    </el-form-item>
			  		</el-col>
			  		<el-col :span="12">
			  			<el-form-item :label="$t('com.isoftchina.hes.common.params.value')" :label-width="formLabelWidth" prop="value">
					   	   <el-input-number class="tl" v-model="data.value" size="mini" controls-position="right" style="width:100%;" :min="1"></el-input-number>	
					    </el-form-item>
			  		</el-col>
			  	</el-row>	
			  	<el-row>
			  		<el-col :span="12">
			  			<el-form-item :label="$t('com.isoftchina.hes.common.params.moudle')" :label-width="formLabelWidth" prop="module">
					   	  <el-input disabled v-model="data.module" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + $t('com.isoftchina.hes.common.params.moudle')" clearable></el-input>
					    </el-form-item>
			  		</el-col>
			  	</el-row>	
			  	<el-row>	
			  		<el-col :span="24">
			  			<el-form-item :label="$t('com.isoftchina.hes.common.description')" :label-width="formLabelWidth" prop="remark">
					      <el-input type="textarea" v-model="data.remark"></el-input>
					    </el-form-item>
			  		</el-col>
			  	</el-row>
		</el-form>
	</section>
</template>
<script>
  export default {
    props:['data'],
  	data() {
      return {
			      	formLabelWidth:'120px',
			      	rules:{
			      		value:[
			      					{required: true, message: (this.$t('com.isoftchina.hes.common.params.value') + this.$t('com.isoftchina.hes.common.notnull')),  trigger: 'blur'}
			      				]
			      	}
     			 }
    }
  };
</script>