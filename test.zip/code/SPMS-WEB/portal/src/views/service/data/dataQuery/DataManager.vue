<template>
	<el-container class="page-container">
		<el-header height="110px">
			<el-form class="vue-form mt20" :model="data" size="mini">
				<el-row>
					<el-col :span="24">
						<el-row>
							<el-col :span="6">
								<el-form-item :label="$t('com.isoftchina.hes.asset.madeNo')" :label-width="formLabelWidth">
									<el-input v-model="data.madeNo" autocomplete="off" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + $t('com.isoftchina.hes.asset.madeNo')" clearable></el-input>
								</el-form-item>
							</el-col>
							<el-col :span="6">
								<el-form-item :label="$t('com.isoftchina.hes.asset.madeNo')" :label-width="formLabelWidth">
									<el-select v-model="data.type" :placeholder="$t('com.isoftchina.hes.common.pleaseSelect')">
										<el-option v-for="item in config.meterTypeMenu" :key="item.value" :label="$t('static.'+item.codeType+'_'+item.value)" :value="item.value"></el-option>
									</el-select>
								</el-form-item>
							</el-col>
						</el-row>
						<el-row>
							<el-col :span="6">
								<el-form-item :label="$t('com.isoftchina.hes.asset.assetNo')" :label-width="formLabelWidth">
									<el-input v-model="data.assetNo" autocomplete="off" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + $t('com.isoftchina.hes.asset.assetNo')" clearable></el-input>
								</el-form-item>
							</el-col>
							<el-col :span="6">
								<el-form-item :label="$t('com.isoftchina.hes.asset.assetName')" :label-width="formLabelWidth">
									<el-input v-model="data.assetName" autocomplete="off" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + $t('com.isoftchina.hes.asset.assetName')" clearable></el-input>
								</el-form-item>
							</el-col>
							<el-col :span="2">&nbsp;</el-col>
							<el-col :span="7">
								<el-button type="primary" icon="fa fa-search" size="mini" @click.native="()=>getDataList()">{{$t('com.isoftchina.hes.common.query')}}</el-button>
								<el-button size="mini" icon="fa fa-eraser" @click.native="()=>reset()">{{$t('com.isoftchina.hes.common.reset')}}</el-button>
							</el-col>
						</el-row>
					</el-col>
				</el-row>
			</el-form>
		</el-header>
		<el-main>
			<div class="full-screen">
				<div style="position:absolute;">
					<el-button type="primary" size="mini" icon="fa fa-plus" @click.stop="()=>operationInfo()">{{$t('com.isoftchina.hes.common.add')}}</el-button>
					<el-button size="mini" icon="fa fa-trash" @click.stop="()=>remove()">{{$t('com.isoftchina.hes.common.del')}}</el-button>
				</div>
				<el-grid :data="dataList" :columns="columns" @row-click="showData" :show-operation="false" @getCheckedRows="getCheckedRows" unique-key="meterId" :formatter="formatter">
					<el-table-column :label="$t('com.isoftchina.hes.common.operation')" width="170" fixed align="center">
						<template slot-scope="{row,$index}">
							<el-tag size="mini" :disable-transitions="true" class="vue-tag" @click.native="()=>operationInfo(row)">{{$t('com.isoftchina.hes.common.modify')}}</el-tag>
						</template>
					</el-table-column>
				</el-grid>
			</div>
		</el-main>
		<el-footer height="40px">
			<el-pagination background :layout="layout" class="fr"
						   :total="total"
						   :page-sizes="pageSizes"
						   :page-size="page.pageSize"
						   :current-page="page.pageNo"
						   @size-change="sizeChange"
						   @current-change="currentChange"></el-pagination>
		</el-footer>
		<el-model v-if="visible" :visible.sync="visible" :title="(isAdd ? $t('com.isoftchina.hes.common.add') : $t('com.isoftchina.hes.common.modify')) + $t('com.isoftchina.hes.asset.meter')" width="750px" @ok-click="submitInfo">
			<DeviceInfo :data="info" :config="config"></DeviceInfo>
		</el-model>
		<el-container>
			<el-tabs type="card" @tab-click="handleClick" value ="first">
				<el-tab-pane label="数据召测与下发" name="first">
					<el-container>
						<el-aside  >
							<el-input placeholder="输入关键字进行过滤" v-model="filterText"> </el-input>
							<el-tree :data="tree" :props="defaultProps" @node-click="handleNodeClick"></el-tree>

						</el-aside>
						<el-main>
							<el-form class="vue-form mt20" :model="tree" size="mini">
								<el-row>
									<el-col :span="12">
										<el-form-item label="数据项名称" :label-width="formLabelWidth">
											<el-input v-model="showName" autocomplete="off" readonly="true" clearable></el-input>
										</el-form-item>
									</el-col>
									<el-col :span="12">
										<el-form-item label="数据项编码" :label-width="formLabelWidth">
											<el-input v-model="showId" autocomplete="off" readonly="true"  clearable></el-input>
										</el-form-item>
									</el-col>
								</el-row>
								<el-row>
									<el-col :span="12">
										<el-form-item label="读写标记" :label-width="formLabelWidth">
											<el-input v-model="showOpType" autocomplete="off" readonly="true"   clearable></el-input>
										</el-form-item>
									</el-col>
									<el-col :span="12">
										<el-form-item label="单位" :label-width="formLabelWidth">
											<el-input v-model="showAttrUnit" autocomplete="off" readonly="true"  clearable></el-input>
										</el-form-item>
									</el-col>
								</el-row>
								<el-row>
									<el-col :span="12">
										<el-form-item label="倍率" :label-width="formLabelWidth">
											<el-input v-model="showValueScale" autocomplete="off" readonly="true"  clearable></el-input>
										</el-form-item>
									</el-col>
									<el-col :span="12">
										<el-form-item label="召测值" :label-width="formLabelWidth">
											<el-input v-model="data.madeNo" autocomplete="off"   clearable></el-input>
										</el-form-item>
									</el-col>
								</el-row>
								<el-row>
									<el-col :span="12">
										<el-form-item label="开始时间" :label-width="formLabelWidth">
											<el-input v-model="data.madeNo" autocomplete="off"   clearable></el-input>
										</el-form-item>
									</el-col>
									<el-col :span="12">
										<el-form-item label="结束时间" :label-width="formLabelWidth">
											<el-input v-model="data.madeNo" autocomplete="off"   clearable></el-input>
										</el-form-item>
									</el-col>
								</el-row>
								<el-row>
									<el-col :span="12">
										<el-form-item label="下发值" :label-width="formLabelWidth">
											<el-input v-model="data.madeNo" autocomplete="off"   clearable></el-input>
										</el-form-item>
									</el-col>
									<el-col :span="12">
										<el-form-item label="结束时间" :label-width="formLabelWidth">
											<el-input v-model="data.madeNo" autocomplete="off"   clearable></el-input>
										</el-form-item>
									</el-col>
								</el-row>
							</el-form>
						</el-main>
					</el-container>

					<el-button type="primary" @click.stop="()=>callData()">召测</el-button>
					<el-button type="primary" @click.stop="()=>sendParam()">下发</el-button>

				</el-tab-pane>

				<!--事件记录-->
				<el-tab-pane label="事件记录" name="second">


				</el-tab-pane>
				<!--数据查询-->
				<el-tab-pane label="数据查询" name="third">


				</el-tab-pane>
			</el-tabs>

		</el-container>
	</el-container>
</template>
<script src="./js/DataList.js"></script>