import DeviceInfo from '@/views/service/resource/device/dialog/DeviceInfo';
import * as deviceService from '@/axios/deviceService';
import * as paramsService from '@/axios/paramsService';
import Pagination from '@/customize/js/pagination';

export default {
    mixins: [Pagination],
    data() {
        return {
            formLabelWidth:"100px",
            info:{},
            data:{},
            isAdd:true,
            config:{},
            visible:false,
            loading:false,
            columns:[
                {label:'com.isoftchina.hes.asset.assetNo',prop:'assetNo',width:'80px',visible:true},
                {label:'com.isoftchina.hes.asset.assetName',prop:'assetName',width:'80px',visible:true},
                {label:'com.isoftchina.hes.asset.madeNo',prop:'madeNo',width:'80px',visible:true},
                {label:'com.isoftchina.hes.asset.model',prop:'model',width:'150px',visible:true},
                {label:'com.isoftchina.hes.asset.manufactor',prop:'manufactor',width:'80px',visible:true},
                {label:'com.isoftchina.hes.asset.simNo',prop:'simNo',width:'80px',visible:true}
            ],
            dataList:[],
            tree:[],
            showName:[],
            showId:[],
            showOpType:[],
            showAttrUnit:[],
            showValueScale:[],
            defaultProps: {
                children: 'children',
                label: 'label'
            },
            formLabelAlign: {
                name: '',
                region: '',
                type: ''
            }

        }
    },
    methods:{
        formatter(row, column,value){
            if(column.property=='model') { return this.$t('static.meterModel_'  + value);}
            else if(column.property=='manufactor') { return this.$t('static.manufactor_'  + value); }
            return value;
        },
        getDataList(){
            this.loading=true;
            let param = Object.assign({params:this.data},this.page);
            deviceService.getMeterList(param).then(res=>{
                this.loading=false;
                if(res.success)
                {
                    this.dataList= res.obj.results;
                    this.total=res.obj.totalRecord;
                    return;
                }
                this.$message.error(this.$i18n.t('com.isoftchina.hes.common.error'));
            });
        },

        showData(row, event){
          //树形展示数据
            let modelid = null;
            deviceService.queryAttributeList(row).then(res=>{
                if(res.success)
                {
                    this.tree= res.obj;
                    return;
                }
                this.$message.error(this.$i18n.t('com.isoftchina.hes.common.error'));
            });
        },

        handleNodeClick(data) {
            deviceService.selectByPrimaryKey(data).then(res=>{
                this.showName.shift();
                this.showId.shift();
                this.showOpType.shift();
                this.showAttrUnit.shift();
                this.showValueScale.shift();
                if(res.success){
                    this.showName.push(data.label);
                    this.showId.push(data.id);
                    this.showOpType.push(data.opType);
                    this.showAttrUnit.push(data.attrUnit);
                    this.showValueScale.push(data.valueScale);
                    return;
                }
                this.$message.error(this.$i18n.t('com.isoftchina.hes.common.error'));
            });
        },
        handleClick(tab, event) {

        },

        callData(data){
            deviceService.callData(data).then(res=>{
                this.$message.success(this.$i18n.t('com.isoftchina.hes.common.success'));
            })
        },

        sendParam(data){
            deviceService.sendParam(data).then(res=>{
                this.$message.success(this.$i18n.t('com.isoftchina.hes.common.success'));
            })
        },

        reset(){
            this.data={};
        },
        operationInfo(row){
            this.info = row ? Object.assign({}, row) : {type:'01',model:'01',manufactor:'01'};
            this.isAdd=!row;
            this.config.isAdd=this.isAdd;
            this.visible=true;
        },
        submitInfo(){
            deviceService[(this.isAdd ? 'add' : 'edit') + 'Meter'](this.info).then(res=>{
                this.$message({ showClose: true, message: (res.success ? this.$t('com.isoftchina.hes.common.success') : this.$t('com.isoftchina.hes.common.fail')), type: (res.success ? 'success' : 'error') });
                this.getDataList();
                this.visible=false;
            });
        },
        remove(){
            // 如果不是单选删除并且选中行数为0，则提示用户
            if(!this.sels.length) { this.$alert(this.$t('com.isoftchina.hes.common.delete.tip'),this.$t('com.isoftchina.hes.layout.header.tip'),{type:'warning'}); return; }
            this.$confirm(this.$t('com.isoftchina.hes.common.delete.comfirm'), this.$t('com.isoftchina.hes.layout.header.tip'), {type: 'warning'}).then(() => {
                // 删除操作
                deviceService.deleteMeter(this.sels).then(res=>{
                    this.$message({ showClose: true, message: (res.success ? this.$t('com.isoftchina.hes.common.success') : this.$t('com.isoftchina.hes.common.fail')), type: (res.success ? 'success' : 'error') });
                    this.getDataList();
                })
            }).catch(() => {});
        }

    },
    components: {
        DeviceInfo
    },
    mounted() {
        this.getDataList();
        // 类别
        paramsService.getDictDataByType("meterType").then(res=>{
            this.$set(this.config,'meterTypeMenu',res.obj);
        })
        // 型号
        paramsService.getDictDataByType("meterModel").then(res=>{
            this.$set(this.config,'meterModelMenu',res.obj);
        })
        // 厂家
        paramsService.getDictDataByType("manufactor").then(res=>{
            this.$set(this.config,'manufactorMenu',res.obj);
        })
    }
};