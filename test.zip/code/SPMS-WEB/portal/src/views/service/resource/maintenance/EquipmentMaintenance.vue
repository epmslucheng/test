<template>
    <el-container class="page-container">
        <el-header height="110px">
            <el-form class="vue-form mt20" :model="data" size="mini">
                <el-row>
                    <el-col :span="24">
                        <el-row>
                            <el-col :span="6">
                                <el-form-item label="电表编号" :label-width="formLabelWidth">
                                    <el-input v-model="data.madeNo" autocomplete="off" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + '电表编号'" clearable></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="6">
                                <el-form-item label="类型" :label-width="formLabelWidth">
                                    <el-select v-model="data.type" :placeholder="$t('com.isoftchina.hes.common.pleaseSelect')">
                                        <el-option v-for="item in config.meterTypeMenu" :key="item.value" :label="$t('static.'+item.codeType+'_'+item.value)" :value="item.value"></el-option>
                                    </el-select>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="6">
                                <el-form-item label="资产编号" :label-width="formLabelWidth">
                                    <el-input v-model="data.assetNo" autocomplete="off" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + '资产编号'" clearable></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="6">
                                <el-form-item label="名称" :label-width="formLabelWidth">
                                    <el-input v-model="data.assetName" autocomplete="off" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + '名称'" clearable></el-input>
                                </el-form-item>
                            </el-col>

                            <el-col :span="6">
                                <el-form-item label="电表状态" :label-width="formLabelWidth">
                                    <el-select v-model="data.meterStatus" :placeholder="$t('com.isoftchina.hes.asset.meterStatus')">
                                        <el-option v-for="item in config.meterStatusMenu" :key="item.value" :label="$t('static.'+item.codeType+'_'+item.value)" :value="item.value"></el-option>
                                    </el-select>
                                </el-form-item>
                            </el-col>

                            <el-col :span="6">
                                <el-button type="primary" size="mini" @click.native="()=>getDataList()">{{$t('com.isoftchina.hes.common.query')}}</el-button>
                                <el-button size="mini" @click.native="()=>reset()">{{$t('com.isoftchina.hes.common.reset')}}</el-button>
                            </el-col>
                        </el-row>
                    </el-col>
                </el-row>
            </el-form>
        </el-header>
        <el-main>
            <div class="full-screen">
                <el-grid :data="dataList" :columns="columns" :show-operation="false" @getCheckedRows="getCheckedRows" unique-key="meterId" :formatter="formatter">
                    <el-table-column :label="$t('com.isoftchina.hes.common.operation')" width="170" fixed align="center">
                        <template slot-scope="scope">
                            <el-tag size="mini" :disable-transitions="true" class="vue-tag" @click.native="()=>install(scope.row)">{{$t('com.isoftchina.hes.asset.install')}}</el-tag>
                            <el-tag size="mini" :disable-transitions="true" class="vue-tag" @click.native="()=>remove(scope.row)">{{$t('com.isoftchina.hes.asset.remove')}}</el-tag>
                        </template>
                    </el-table-column>
                </el-grid>
            </div>
        </el-main>
        <el-footer height="40px">
            <el-pagination background :layout="layout" class="fr"
                           :total="total"
                           :page-sizes="pageSizes"
                           :page-size="page.pageSize"
                           :current-page="page.pageNo"
                           @size-change="sizeChange"
                           @current-change="currentChange"></el-pagination>
        </el-footer>
        <el-model v-if="visible" :visible.sync="visible" :title="$t('com.isoftchina.hes.asset.install') + $t('com.isoftchina.hes.asset.meter')" width="750px" @ok-click="install">
            <DeviceInfo :data="info" :config="config"></DeviceInfo>
        </el-model>
    </el-container>
</template>
<script src="./js/EquipmentMaintenance.js"></script>