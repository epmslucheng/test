<template>
	<section>
		<el-form class="vue-form" :model="data" :rules="rules" size="mini">
			  	<el-row>
			  		<el-col :span="12">
						<el-form-item :label="$t('com.isoftchina.hes.asset.type')" :label-width="formLabelWidth">
							<el-select :disabled="!config.isAdd || config.filterable" v-model="data.type" :placeholder="$t('com.isoftchina.hes.common.pleaseSelect')">
								<el-option v-for="item in config.meterTypeMenu" :key="item.value" :label="$t('static.'+item.codeType+'_'+item.value)" :value="item.value"></el-option>
							</el-select>
						</el-form-item>
			  		</el-col>
			  		<el-col :span="12">
						<el-form-item :label="$t('com.isoftchina.hes.asset.model')" :label-width="formLabelWidth">
							<el-select :disabled="!config.isAdd || config.filterable" v-model="data.model" :placeholder="$t('com.isoftchina.hes.common.pleaseSelect')">
								<el-option v-for="item in config.meterModelMenu" :key="item.value" :label="$t('static.'+item.codeType+'_'+item.value)" :value="item.value"></el-option>
							</el-select>
						</el-form-item>
			  		</el-col>
			  	</el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item :label="$t('com.isoftchina.hes.asset.madeNo')" :label-width="formLabelWidth" prop="madeNo">
                            <el-input :disabled="!config.isAdd || config.filterable" v-model="data.madeNo" autocomplete="off" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + $t('com.isoftchina.hes.asset.madeNo')" clearable></el-input>
                        </el-form-item>
                    </el-col>
					<el-col :span="12">
						<el-form-item :label="$t('com.isoftchina.hes.asset.assetNo')" :label-width="formLabelWidth" prop="assetNo">
							<el-input :disabled="!config.isAdd || config.filterable" v-model="data.assetNo" autocomplete="off" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + $t('com.isoftchina.hes.asset.assetNo')" clearable></el-input>
						</el-form-item>
			  		</el-col>
			  	</el-row>
            <el-row>
                <el-col :span="12">
                    <el-form-item :label="$t('com.isoftchina.hes.asset.madeNo')" :label-width="formLabelWidth" prop="assetName">
                        <el-input v-model="data.assetName" autocomplete="off" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + $t('com.isoftchina.hes.asset.madeNo')" clearable></el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="12">
                    <el-form-item :label="$t('com.isoftchina.hes.asset.manufactor')" :label-width="formLabelWidth">
                        <el-select v-model="data.manufactor" :placeholder="$t('com.isoftchina.hes.common.pleaseSelect')">
                            <el-option v-for="item in config.manufactorMenu" :key="item.value" :label="$t('static.'+item.codeType+'_'+item.value)" :value="item.value"></el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row>
                <el-col :span="12">
                    <el-form-item :label="$t('com.isoftchina.hes.asset.simNo')" :label-width="formLabelWidth" prop="simNo">
                        <el-input v-model="data.simNo" autocomplete="off" :placeholder="$t('com.isoftchina.hes.common.pleaseEnter') + $t('com.isoftchina.hes.asset.simNo')" clearable></el-input>
                    </el-form-item>
                </el-col>
            </el-row>
		</el-form>
	</section>
</template>
<script>
  export default {
      props:['data','config'],
  	  data() {
     		 return {
			      	formLabelWidth:'80px',
			      	rules:{
                        assetNo:[
			      					{required: true, message: '资产编号不能为空',  trigger: 'blur'}
			      				],
                        madeNo:[
                            {required: true, message: '电表编号不能为空',  trigger: 'blur'}
                        ],
                        assetName:[
                            		{required: true, message: '资产名称不能为空',  trigger: 'blur'}
                        		],
                        simNo:[
                            		{required: true, message: '手机号码不能为空',  trigger: 'blur'},
                                    {validator: this.$validate.checkPhoneNumber ,message: this.$t('com.isoftchina.hes.common.phone'),trigger: 'blur'}
                        		]
			      	}
     			 }
    }
  };
</script>