import DeviceInfo from '@/views/service/resource/device/dialog/DeviceInfo';
import * as deviceService from '@/axios/deviceService';
import * as paramsService from '@/axios/paramsService';
import Pagination from '@/customize/js/pagination';

export default {
    mixins: [Pagination],
    data() {
        return {
            formLabelWidth:"100px",
            info:{},
            data:{},
            isInstall:true,
            config:{},
            visible:false,
            loading:false,
            columns:[
                {label:'com.isoftchina.hes.asset.assetNo',prop:'assetNo',width:'80px',visible:true},
                {label:'com.isoftchina.hes.asset.meterStatus',prop:'debugged',width:'80px',visible:true},
                {label:'com.isoftchina.hes.asset.assetName',prop:'assetName',width:'80px',visible:true},
                {label:'com.isoftchina.hes.asset.madeNo',prop:'madeNo',width:'80px',visible:true},
                {label:'com.isoftchina.hes.asset.model',prop:'model',width:'150px',visible:true},
                {label:'com.isoftchina.hes.asset.manufactor',prop:'manufactor',width:'80px',visible:true},
                {label:'com.isoftchina.hes.asset.simNo',prop:'simNo',width:'80px',visible:true}
            ],
            dataList:[]
        }
    },
    methods:{
        formatter(row, column,value){
            if(column.property=='model') { return this.$t('static.meterModel_'  + value);}
            else if(column.property=='manufactor') { return this.$t('static.manufactor_'  + value); }
            else if(column.property=='debugged') { return this.$t('static.meterStatus_'  + value); }
            return value;
        },
        getDataList(){
            this.loading=true;
            let param = Object.assign({params:this.data},this.page);
            deviceService.getMeterVoList(param).then(res=>{
                this.loading=false;
                if(res.success)
                {
                    this.dataList= res.obj.results;
                    this.total=res.obj.totalRecord;
                    return;
                }
                this.$message.error(this.$i18n.t('com.isoftchina.hes.common.error'));
            });
        },
        reset(){
            this.data={};
        },
        install(row){
            //安装电表
            deviceService.meterInstall(row.meterId).then(res=>{
                this.$message({ showClose: true, message: (res.success ? this.$t('com.isoftchina.hes.common.success') : this.$t('com.isoftchina.hes.common.fail')), type: (res.success ? 'success' : 'error') });
                this.getDataList();
            });
        },
        remove(row){
            // 删除操作
            deviceService.meterRemove(row.meterId).then(res=>{
                this.$message({ showClose: true, message: (res.success ? this.$t('com.isoftchina.hes.common.success') : this.$t('com.isoftchina.hes.common.fail')), type: (res.success ? 'success' : 'error') });
                this.getDataList();
            });
        }
    },
    components: {
        DeviceInfo
    },
    mounted() {
        this.getDataList();
        // 类别
        paramsService.getDictDataByType("meterType").then(res=>{
            this.$set(this.config,'meterTypeMenu',res.obj);
        })
        // 型号
        paramsService.getDictDataByType("meterModel").then(res=>{
            this.$set(this.config,'meterModelMenu',res.obj);
        })
        // 厂家
        paramsService.getDictDataByType("manufactor").then(res=>{
            this.$set(this.config,'manufactorMenu',res.obj);
        })
        //电表状态
        paramsService.getDictDataByType("meterStatus").then(res=>{
            this.$set(this.config,'meterStatusMenu',res.obj);
        })
    }
};