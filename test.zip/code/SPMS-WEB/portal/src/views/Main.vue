<template>
	<section class="full-height">
		<el-row class="full-width full-height">
			<el-col :span="24" class="full-height">
				<div class="full-width full-height grad">
					<img :src="this.sysAvatar" v-if="sysAvatar" style=""/>
				</div>
			</el-col>
		</el-row>
	</section>
</template>

<script>
	export default {
		data(){
			return{
				sysAvatar:require('@/assets/map-home.png'),
			}
		}
	}

</script>

<style scoped>
.grad {
  background: -webkit-linear-gradient(#fff, #dff1e8); /* Safari 5.1 - 6.0 */
  background: -o-linear-gradient(#fff, #dff1e8); /* Opera 11.1 - 12.0 */
  background: -moz-linear-gradient(#fff, #dff1e8); /* Firefox 3.6 - 15 */
  background: linear-gradient(#fff, #dff1e8); /* 标准的语法 */
}
img{position:absolute;left:0;right:0;top:0;bottom:0;margin:auto;}
</style>